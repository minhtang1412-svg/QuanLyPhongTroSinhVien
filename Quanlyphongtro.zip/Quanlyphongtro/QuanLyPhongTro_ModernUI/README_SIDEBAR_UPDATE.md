# CẬP NHẬT CẤU TRÚC SIDEBAR

Đã tổ chức lại thanh điều hướng theo module nghiệp vụ, thay vì liệt kê toàn bộ chức năng ngang hàng.

## Cấu trúc mới

- Trang chủ
- Quản lý cho thuê
  - Nhà trọ
  - Phòng
  - Khách thuê
  - Hợp đồng
- Tài chính
  - Tính tiền
  - Hóa đơn
  - Phiếu chi
  - Lịch sử giao dịch
- Vận hành
  - Công việc
  - Tài sản
  - Thông báo (lịch sử gửi email/SMS)
- Báo cáo
  - Báo cáo
- Hệ thống
  - Tài khoản
  - Thiết lập

## UX

- Sidebar rộng 235px để các nhãn dài không bị chật.
- Các nhóm dùng accordion: chỉ một module được mở tại một thời điểm.
- Mặc định mở “Quản lý cho thuê”.
- Mục đang chọn được tô màu xanh chủ đạo.
- Hover nhẹ cho mục chưa chọn.
- Tài sản được đưa về Vận hành.
- “Lịch sử gửi email/SMS” đổi thành “Thông báo” để ngắn gọn và đúng nhóm nghiệp vụ hơn.
- Giữ nguyên các page/chức năng và luồng điều hướng hiện có.

Tài khoản mặc định: admin / admin123.
