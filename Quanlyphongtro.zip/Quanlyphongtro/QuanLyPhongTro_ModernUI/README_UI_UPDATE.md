# Bản cập nhật giao diện theo mẫu

Đã chỉnh lại giao diện màn hình Trang chủ theo ảnh mẫu:
- Sidebar tối 196px, nhóm chức năng dạng accordion.
- Thanh trên cùng có menu, ô tìm kiếm, thông báo, giao diện, tài khoản và Đăng xuất.
- Dashboard nền sáng, 8 thẻ thống kê dạng bo góc.
- Ba khối bảng cảnh báo/công nợ/hợp đồng ở phía dưới.
- Giữ nguyên các màn hình và chức năng quản lý hiện có.
- Dữ liệu nghiệp vụ trong `qlpt_data.dat` được giữ nguyên.

Chạy `run.bat` hoặc `QuanLyPhongTro.jar`.
