package com.qlpt.ui;

import com.qlpt.model.User;
import com.qlpt.util.Theme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicButtonUI;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.LinkedHashMap;
import java.util.Map;

public class MainFrame extends JFrame {
    private final User currentUser;
    private DashboardPanel dashboardPanel;
    private RoomPanel roomPanel; private TenantPanel tenantPanel; private ContractPanel contractPanel; private InvoicePanel invoicePanel;
    private ReportPanel reportPanel; private PaymentCalculatorPanel paymentCalculatorPanel; private ExpensePanel expensePanel;
    private CommunicationPanel communicationPanel; private AssetPanel assetPanel; private PropertyPanel propertyPanel; private TaskPanel taskPanel;
    private SettingsPanel settingsPanel; private TransactionPanel transactionPanel; private InvoiceHistoryPanel invoiceHistoryPanel; private AccountPanel accountPanel;
    private JPanel sidebarPanel, contentPanel; private CardLayout cardLayout;
    private final Map<String,JButton> navButtons=new LinkedHashMap<>();
    private final Map<String,JPanel> sectionBodies=new LinkedHashMap<>();
    private final Map<String,JButton> sectionHeaders=new LinkedHashMap<>();
    private String activeNavKey="dashboard", openSection="lease"; private JLabel avatar;
    private static final Color SIDEBAR=Theme.SIDEBAR, SIDEBAR2=new Color(31,52,68), ACTIVE=new Color(58,84,104);

    public MainFrame(User currentUser){this.currentUser=currentUser; Theme.setup(); initUI();}

    private void initUI(){
        setTitle("Quản lý nhà trọ"); setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1080,680)); setSize(1280,780); setLocationRelativeTo(null);
        JPanel root=new JPanel(new BorderLayout()); root.setBackground(Theme.BG); setContentPane(root);
        sidebarPanel=buildSidebar(); root.add(sidebarPanel,BorderLayout.WEST);
        JPanel main=new JPanel(new BorderLayout()); main.setBackground(Theme.BG); main.add(buildTopBar(),BorderLayout.NORTH);
        cardLayout=new CardLayout(); contentPanel=new JPanel(cardLayout); contentPanel.setBackground(Theme.BG);
        main.add(contentPanel,BorderLayout.CENTER); root.add(main,BorderLayout.CENTER);
        dashboardPanel=new DashboardPanel(this); roomPanel=new RoomPanel(this); tenantPanel=new TenantPanel(this); contractPanel=new ContractPanel(this); invoicePanel=new InvoicePanel(this);
        reportPanel=new ReportPanel(this); paymentCalculatorPanel=new PaymentCalculatorPanel(this); expensePanel=new ExpensePanel(this); communicationPanel=new CommunicationPanel(this); assetPanel=new AssetPanel(this);
        propertyPanel=new PropertyPanel(this); taskPanel=new TaskPanel(this); settingsPanel=new SettingsPanel(this); transactionPanel=new TransactionPanel(this); invoiceHistoryPanel=new InvoiceHistoryPanel(this); accountPanel=new AccountPanel(this);
        addPage("dashboard",dashboardPanel); addPage("rooms",roomPanel); addPage("tenants",tenantPanel); addPage("contracts",contractPanel); addPage("invoices",invoicePanel); addPage("reports",reportPanel);
        addPage("payments",paymentCalculatorPanel); addPage("expenses",expensePanel); addPage("communications",communicationPanel); addPage("transactions",transactionPanel); addPage("tasks",taskPanel); addPage("assets",assetPanel); addPage("properties",propertyPanel); addPage("account",accountPanel); addPage("invoice_history",invoiceHistoryPanel); addPage("settings",settingsPanel);
        showPage("dashboard","Trang chủ");
    }

    private JPanel buildTopBar(){
        JPanel bar=new JPanel(new BorderLayout()); bar.setPreferredSize(new Dimension(0,70)); bar.setBackground(Color.WHITE);
        bar.setBorder(BorderFactory.createMatteBorder(0,0,1,0,Theme.BORDER));
        JButton menu=flatButton("☰",22); menu.setToolTipText("Ẩn/hiện thanh điều hướng"); menu.addActionListener(e->toggleSidebar());
        JPanel left=new JPanel(new FlowLayout(FlowLayout.LEFT,18,17)); left.setOpaque(false); left.add(menu); bar.add(left,BorderLayout.WEST);

        JPanel right=new JPanel(new FlowLayout(FlowLayout.RIGHT,10,15)); right.setOpaque(false);
        JTextField search=new JTextField(); Theme.styleInput(search); search.setPreferredSize(new Dimension(220,40));
        search.putClientProperty("JTextField.placeholderText","Tìm kiếm..."); right.add(search);
        JButton bell=flatButton("♧",21); bell.setToolTipText("Thông báo"); right.add(badgeButton(bell,"1"));
        JButton theme=flatButton("☼",22); theme.setToolTipText("Giao diện"); right.add(theme);
        avatar=new JLabel(initial(currentUser==null?"U":currentUser.getFullName()),SwingConstants.CENTER); avatar.setOpaque(true); avatar.setBackground(Theme.NAVY); avatar.setForeground(Color.WHITE); avatar.setFont(new Font("Segoe UI",Font.BOLD,14)); avatar.setPreferredSize(new Dimension(36,36)); avatar.setBorder(new EmptyBorder(0,0,0,0)); right.add(avatar);
        JLabel name=new JLabel(currentUser==null?"Admin":currentUser.getFullName()); name.setForeground(Theme.TEXT); name.setFont(new Font("Segoe UI",Font.BOLD,13)); right.add(name);
        JButton drop=flatButton("⌄",15); right.add(drop);
        JButton logout=new JButton("↪  Đăng xuất"); logout.setUI(new BasicButtonUI());
        logout.setForeground(Color.WHITE); logout.setBackground(new Color(195,59,59)); logout.setOpaque(true); logout.setContentAreaFilled(true); logout.setBorderPainted(false); logout.setFont(new Font("Segoe UI",Font.BOLD,14));
        logout.setBorder(new EmptyBorder(10,15,10,15)); logout.setFocusPainted(false); logout.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        logout.addMouseListener(new MouseAdapter(){ public void mouseEntered(MouseEvent e){ logout.setBackground(new Color(214,76,76)); } public void mouseExited(MouseEvent e){ logout.setBackground(new Color(195,59,59)); } });
        logout.addActionListener(e->logout()); right.add(logout);
        bar.add(right,BorderLayout.EAST); return bar;
    }

    private JButton flatButton(String t,int size){JButton b=new JButton(t); b.setBorderPainted(false); b.setContentAreaFilled(false); b.setFocusPainted(false); b.setForeground(new Color(47,57,66)); b.setFont(new Font("Segoe UI Symbol",Font.PLAIN,size)); b.setPreferredSize(new Dimension(38,38)); return b;}
    private JButton badgeButton(JButton base,String n){
        JPanel p=new JPanel(new BorderLayout()); p.setOpaque(false); JLabel badge=new JLabel(n,SwingConstants.CENTER); badge.setOpaque(true); badge.setBackground(new Color(37,103,189)); badge.setForeground(Color.WHITE); badge.setFont(new Font("Segoe UI",Font.BOLD,9)); badge.setPreferredSize(new Dimension(16,16)); badge.setBorder(BorderFactory.createLineBorder(Color.WHITE)); p.add(base,BorderLayout.CENTER); p.add(badge,BorderLayout.EAST);
        JButton b=new JButton(); b.setOpaque(false); b.setContentAreaFilled(false); b.setBorderPainted(false); b.setFocusPainted(false); b.setLayout(new BorderLayout()); b.add(p); b.setPreferredSize(new Dimension(44,38)); b.addActionListener(e->showNotifications()); return b;
    }

    private JPanel buildSidebar(){
        JPanel outer=new JPanel(new BorderLayout()); outer.setPreferredSize(new Dimension(220,0)); outer.setBackground(SIDEBAR);
        JPanel inner=new JPanel(); inner.setBackground(SIDEBAR); inner.setLayout(new BoxLayout(inner,BoxLayout.Y_AXIS)); inner.setBorder(new EmptyBorder(12,10,14,10));
        JLabel brand=new JLabel("▣  QUẢN LÝ NHÀ TRỌ"); brand.setForeground(Color.WHITE); brand.setFont(new Font("Segoe UI",Font.BOLD,16)); brand.setBorder(new EmptyBorder(8,9,22,4)); brand.setAlignmentX(Component.LEFT_ALIGNMENT); inner.add(brand);
        addNav(inner,"⌂","dashboard","Trang chủ");
        addSection(inner,"lease","⌂","QUẢN LÝ CHO THUÊ",new String[][]{{"properties","Nhà trọ","▣"},{"rooms","Phòng","▤"},{"tenants","Khách thuê","♙"},{"contracts","Hợp đồng","▧"}});
        addSection(inner,"finance","▤","TÀI CHÍNH",new String[][]{{"payments","Tính tiền","▣"},{"invoices","Hóa đơn","▤"},{"expenses","Phiếu chi","▧"},{"transactions","Lịch sử giao dịch","↻"}});
        addSection(inner,"operation","♧","VẬN HÀNH",new String[][]{{"tasks","Công việc","✓"},{"assets","Tài sản","▣"},{"communications","Thông báo","♧"}});
        addSection(inner,"reports","▥","BÁO CÁO",new String[][]{{"reports","Báo cáo","▥"}});
        addSection(inner,"system","⚙","HỆ THỐNG",new String[][]{{"account","Tài khoản","♙"},{"settings","Thiết lập","⚙"}});
        inner.add(Box.createVerticalGlue()); JLabel hint=new JLabel("<html><div style='padding:4px 8px;'>Các chức năng được nhóm theo nghiệp vụ</div></html>"); hint.setForeground(new Color(157,177,191)); hint.setFont(new Font("Segoe UI",Font.PLAIN,11)); inner.add(hint); outer.add(inner,BorderLayout.CENTER); return outer;
    }

    private void addSection(JPanel parent,String key,String icon,String title,String[][] items){
        JButton h=new JButton("  "+title+"                         "+(key.equals(openSection)?"⌄":"›")); h.setHorizontalAlignment(SwingConstants.LEFT); h.setMaximumSize(new Dimension(Integer.MAX_VALUE,36)); h.setPreferredSize(new Dimension(200,36)); h.setForeground(new Color(171,190,202)); h.setBackground(SIDEBAR); h.setFont(new Font("Segoe UI",Font.BOLD,11)); h.setBorder(new EmptyBorder(8,5,6,4)); h.setBorderPainted(false); h.setFocusPainted(false); h.setContentAreaFilled(true); h.setOpaque(true); sectionHeaders.put(key,h);
        JPanel body=new JPanel(); body.setLayout(new BoxLayout(body,BoxLayout.Y_AXIS)); body.setBackground(SIDEBAR); body.setBorder(new EmptyBorder(0,0,5,0)); for(String[] item:items)addNav(body,item[2],item[0],item[1]); sectionBodies.put(key,body); parent.add(h); parent.add(body); h.addActionListener(e->toggleSection(key)); body.setVisible(key.equals(openSection));
    }
    private void toggleSection(String key){openSection=key; for(Map.Entry<String,JPanel> e:sectionBodies.entrySet())e.getValue().setVisible(e.getKey().equals(key)); for(Map.Entry<String,JButton> e:sectionHeaders.entrySet()){String t=e.getValue().getText(); int p=Math.max(t.lastIndexOf("⌄"),t.lastIndexOf("›")); if(p>=0)e.getValue().setText(t.substring(0,p)+(e.getKey().equals(key)?"⌄":"›"));} sidebarPanel.revalidate(); sidebarPanel.repaint();}
    private void addNav(JPanel parent,String icon,String key,String title){
        JButton b=new JButton("  "+icon+"   "+title); b.setHorizontalAlignment(SwingConstants.LEFT); b.setMaximumSize(new Dimension(Integer.MAX_VALUE,40)); b.setPreferredSize(new Dimension(200,40)); b.setForeground(Color.WHITE); b.setBackground(SIDEBAR); b.setFont(new Font("Segoe UI",Font.PLAIN,14)); b.setBorder(new EmptyBorder(8,8,8,7)); b.setBorderPainted(false); b.setContentAreaFilled(true); b.setFocusPainted(false); b.setOpaque(true); b.setUI(new BasicButtonUI()); b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addMouseListener(new MouseAdapter(){public void mouseEntered(MouseEvent e){if(!key.equals(activeNavKey))b.setBackground(SIDEBAR2);} public void mouseExited(MouseEvent e){if(!key.equals(activeNavKey))b.setBackground(SIDEBAR);}}); b.addActionListener(e->showPage(key,title)); navButtons.put(key,b); parent.add(b);
    }
    private void addPage(String key,JPanel p){contentPanel.add(p,key);}
    private void showPage(String key,String title){activeNavKey=key; cardLayout.show(contentPanel,key); for(Map.Entry<String,JButton> e:navButtons.entrySet()){boolean a=e.getKey().equals(key); e.getValue().setBackground(a?ACTIVE:SIDEBAR); e.getValue().setForeground(Color.WHITE);} setTitle("Quản lý nhà trọ • "+title);}
    public void showPagePublic(String key,String title){showPage(key,title);} public void showRoomsOfProperty(int propertyId){roomPanel.setPropertyFilter(propertyId);showPage("rooms","Phòng");}
    private void toggleSidebar(){sidebarPanel.setVisible(!sidebarPanel.isVisible()); revalidate();}
    public User getCurrentUser(){return currentUser;}
    public void refreshAll(){if(dashboardPanel!=null)dashboardPanel.refresh(); if(roomPanel!=null)roomPanel.refresh(); if(tenantPanel!=null)tenantPanel.refresh(); if(contractPanel!=null)contractPanel.refresh(); if(invoicePanel!=null)invoicePanel.refresh(); if(reportPanel!=null)reportPanel.refresh(); if(expensePanel!=null)expensePanel.refresh(); if(communicationPanel!=null)communicationPanel.refresh(); if(assetPanel!=null)assetPanel.refresh(); if(propertyPanel!=null)propertyPanel.refresh(); if(transactionPanel!=null)transactionPanel.refresh(); if(invoiceHistoryPanel!=null)invoiceHistoryPanel.refresh(); if(accountPanel!=null)accountPanel.refresh();}
    public void refreshTopBar(){if(avatar!=null)avatar.setText(initial(currentUser==null?"U":currentUser.getFullName()));}
    private String initial(String n){return n==null||n.isBlank()?"U":n.substring(0,1).toUpperCase();}
    private void showNotifications(){JOptionPane.showMessageDialog(this,"Kiểm tra cảnh báo quá hạn tại Trang chủ.","Thông báo",JOptionPane.INFORMATION_MESSAGE);}
    private void logout(){dispose();SwingUtilities.invokeLater(()->new LoginFrame().setVisible(true));}
}
