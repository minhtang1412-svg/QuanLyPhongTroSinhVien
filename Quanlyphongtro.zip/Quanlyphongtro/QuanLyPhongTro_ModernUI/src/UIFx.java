package com.qlpt.ui;

import com.qlpt.util.Theme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import javax.swing.text.JTextComponent;

/**
 * Cac tien ich giao dien dung chung cho module Hop dong / Khach thue / Gia han:
 *  - Hieu ung sang len khi di chuot vao nut (hover) va vien nhan biet khi dang focus o o nhap.
 *  - To mau xen ke (zebra) + lam noi bat dong dang duoc tro toi trong bang.
 *  - The (badge) mau sac cho cot trang thai, giup nguoi dung nhan biet nhanh bang mau.
 * Khong thay doi Theme.java hien co de tranh anh huong cac man hinh khac; chi bo sung them.
 */
final class UIFx {
    private UIFx() {}

    // ----- Mau sac -----
    static Color brighten(Color c, float amount) {
        int r = clamp((int) (c.getRed() + (255 - c.getRed()) * amount));
        int g = clamp((int) (c.getGreen() + (255 - c.getGreen()) * amount));
        int b = clamp((int) (c.getBlue() + (255 - c.getBlue()) * amount));
        return new Color(r, g, b);
    }

    static Color darken(Color c, float amount) {
        int r = clamp((int) (c.getRed() * (1 - amount)));
        int g = clamp((int) (c.getGreen() * (1 - amount)));
        int b = clamp((int) (c.getBlue() * (1 - amount)));
        return new Color(r, g, b);
    }

    private static int clamp(int v) { return Math.max(0, Math.min(255, v)); }

    // ----- Hover cho nut bam -----
    /** Nut sang len va co vien nhan manh o day khi di chuot vao; tro lai binh thuong khi roi chuot. */
    static void hoverButton(AbstractButton b, Color base) {
        final Color hover = brighten(base, 0.20f);
        final Color pressed = darken(base, 0.12f);
        final javax.swing.border.Border normalBorder = b.getBorder();
        final javax.swing.border.Border hoverBorder = BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 2, 0, darken(base, 0.30f)),
                new EmptyBorder(9, 15, 7, 15));
        b.setBackground(base);
        b.setForeground(Color.WHITE);
        b.setOpaque(true);
        b.setContentAreaFilled(true);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                if (!b.isEnabled()) return;
                b.setBackground(hover);
                b.setBorder(hoverBorder);
            }
            public void mouseExited(MouseEvent e) {
                if (!b.isEnabled()) return;
                b.setBackground(base);
                b.setBorder(normalBorder);
            }
            public void mousePressed(MouseEvent e) {
                if (b.isEnabled()) b.setBackground(pressed);
            }
            public void mouseReleased(MouseEvent e) {
                if (!b.isEnabled()) return;
                Point p = e.getPoint();
                b.setBackground(b.contains(p) ? hover : base);
            }
        });
    }

    // ----- Focus highlight cho o nhap lieu -----
    /** Vien o nhap chuyen sang mau nhan manh va day hon khi duoc chon (focus), tao cam giac ro rang dang thao tac o nao. */
    static void hoverInput(JTextComponent... fields) {
        for (JTextComponent f : fields) hoverInput(f);
    }
    static void hoverInput(JTextComponent f) {
        final javax.swing.border.Border normal = f.getBorder();
        final javax.swing.border.Border focused = BorderFactory.createCompoundBorder(
                new LineBorder(Theme.PRIMARY, 2, true),
                new EmptyBorder(7, 9, 7, 9));
        f.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) { f.setBorder(focused); }
            public void focusLost(FocusEvent e) { f.setBorder(normal); }
        });
    }

    // ----- Hover + zebra cho bang -----
    /** Bat theo doi vi tri chuot tren bang de renderer biet dong nao can lam noi bat. */
    static void enableRowHover(JTable table) {
        table.putClientProperty("hoveredRow", -1);
        table.addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseMoved(MouseEvent e) {
                int row = table.rowAtPoint(e.getPoint());
                Object old = table.getClientProperty("hoveredRow");
                if (old == null || !old.equals(row)) {
                    table.putClientProperty("hoveredRow", row);
                    table.repaint();
                }
            }
        });
        table.addMouseListener(new MouseAdapter() {
            public void mouseExited(MouseEvent e) {
                table.putClientProperty("hoveredRow", -1);
                table.repaint();
            }
        });
    }

    private static final Color HOVER_TINT = new Color(224, 240, 253);
    private static final Color ZEBRA_TINT = new Color(246, 249, 252);

    /** Mau nen chuan cho 1 o: uu tien dang chon > dang hover > xen ke mau nhe. */
    static Color rowBackground(JTable table, int viewRow, boolean isSelected) {
        if (isSelected) return table.getSelectionBackground();
        Object hovered = table.getClientProperty("hoveredRow");
        if (hovered instanceof Integer && (Integer) hovered == viewRow) return HOVER_TINT;
        return (viewRow % 2 == 0) ? Color.WHITE : ZEBRA_TINT;
    }

    /** Renderer chuan: zebra + hover, dung cho cac cot van ban/so thong thuong. */
    static class ZebraCellRenderer extends DefaultTableCellRenderer {
        private final JTable table;
        private final int alignment;
        ZebraCellRenderer(JTable table) { this(table, SwingConstants.LEFT); }
        ZebraCellRenderer(JTable table, int alignment) { this.table = table; this.alignment = alignment; setHorizontalAlignment(alignment); }
        public Component getTableCellRendererComponent(JTable t, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            JLabel c = (JLabel) super.getTableCellRendererComponent(t, value, isSelected, false, row, column);
            c.setBackground(rowBackground(table, row, isSelected));
            c.setForeground(isSelected ? table.getSelectionForeground() : Theme.TEXT);
            c.setBorder(new EmptyBorder(0, 10, 0, 10));
            c.setHorizontalAlignment(alignment);
            return c;
        }
    }

    /** Renderer dang the (pill/badge) mau sac cho cot trang thai, giup nhan dien nhanh bang mau sac thay vi chi chu. */
    static class StatusPillRenderer extends JLabel implements TableCellRenderer {
        private final JTable table;
        private Color rowBg = Color.WHITE;
        private Color badgeBg = Color.WHITE;

        StatusPillRenderer(JTable table) {
            this.table = table;
            setOpaque(false);
            setHorizontalAlignment(SwingConstants.CENTER);
            setFont(new Font("Segoe UI", Font.BOLD, 12));
        }

        public Component getTableCellRendererComponent(JTable t, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            String status = value == null ? "" : value.toString();
            setText(status);
            rowBg = rowBackground(table, row, isSelected);
            Color fg;
            if (status.contains("Sắp") || status.contains("sắp")) { badgeBg = new Color(255, 238, 214); fg = new Color(178, 98, 4); }
            else if (status.contains("Đang thuê")) { badgeBg = new Color(224, 247, 232); fg = new Color(30, 132, 73); }
            else if (status.contains("Đã kết thúc")) { badgeBg = new Color(236, 238, 241); fg = new Color(100, 108, 116); }
            else if (status.contains("Chưa có")) { badgeBg = new Color(236, 238, 241); fg = Theme.MUTED; }
            else { badgeBg = new Color(255, 235, 235); fg = Theme.RED; }
            setForeground(fg);
            return this;
        }

        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(rowBg);
            g2.fillRect(0, 0, getWidth(), getHeight());
            if (getText() != null && !getText().isEmpty()) {
                g2.setColor(badgeBg);
                int pad = 5;
                g2.fillRoundRect(pad, 4, Math.max(0, getWidth() - pad * 2), Math.max(0, getHeight() - 8), 14, 14);
            }
            g2.dispose();
            super.paintComponent(g);
        }
    }

    // ----- Nhan tieu de nhom cho form (dialog) -----
    /** Tao mot nhan tieu de nhom voi vach mau nhan manh ben trai, giup chia bo cuc form ro rang, de theo doi. */
    static JPanel sectionHeader(String text, Color accent) {
        JPanel p = new JPanel(new BorderLayout(8, 0));
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(6, 0, 6, 0));
        JPanel bar = new JPanel();
        bar.setBackground(accent);
        bar.setPreferredSize(new Dimension(4, 18));
        JLabel l = new JLabel(text.toUpperCase());
        l.setFont(new Font("Segoe UI", Font.BOLD, 12));
        l.setForeground(Theme.MUTED);
        p.add(bar, BorderLayout.WEST);
        p.add(l, BorderLayout.CENTER);
        return p;
    }
}
