package com.qlpt.ui;

import com.qlpt.data.DataManager;
import com.qlpt.model.Contract;
import com.qlpt.model.Property;
import com.qlpt.model.Room;
import com.qlpt.model.Tenant;
import com.qlpt.util.Theme;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.format.DateTimeFormatter;

public class ContractPanel extends JPanel {
    private final MainFrame mainFrame;
    private final DataManager dm;
    private DefaultTableModel model;
    private JTable table;
    private JComboBox<String> statusFilter;
    private JComboBox<String> propertyFilter;
    private JComboBox<String> roomFilter;
    private JTextField searchField;
    private JLabel countLabel;

    public ContractPanel(MainFrame mainFrame){
        this.mainFrame=mainFrame; this.dm=DataManager.getInstance();
        setLayout(new BorderLayout(12,12)); setBorder(BorderFactory.createEmptyBorder(18,18,18,18)); setBackground(Theme.BG);
        add(buildToolbar(),BorderLayout.NORTH);
        model=new DefaultTableModel(new Object[]{"ID","Khu trọ","Phòng","Người thuê","Ngày bắt đầu","Ngày kết thúc","Ngày nộp tiền","Tiền cọc","Giá thuê/tháng","Trạng thái"},0){ public boolean isCellEditable(int r,int c){return false;} };
        table=new JTable(model); Theme.styleTable(table); table.setRowHeight(34); table.setAutoCreateRowSorter(true);
        applyTableRenderers();
        JScrollPane scroll=new JScrollPane(table); scroll.setBorder(BorderFactory.createLineBorder(Theme.BORDER,1));
        add(scroll,BorderLayout.CENTER); refresh();
    }

    private void applyTableRenderers(){
        UIFx.enableRowHover(table);
        int[] moneyCols={7,8};
        for(int i=0;i<table.getColumnCount();i++){
            if(i==9){ table.getColumnModel().getColumn(i).setCellRenderer(new UIFx.StatusPillRenderer(table)); continue; }
            int align = SwingConstants.LEFT;
            for(int m:moneyCols) if(m==i) align=SwingConstants.RIGHT;
            if(i==0) align=SwingConstants.CENTER;
            table.getColumnModel().getColumn(i).setCellRenderer(new UIFx.ZebraCellRenderer(table, align));
        }
    }

    private JPanel buildToolbar(){
        JPanel wrap=new JPanel(); wrap.setOpaque(false); wrap.setLayout(new BoxLayout(wrap,BoxLayout.Y_AXIS));

        // Hang 1: cac thao tac chinh, phan nhom ro rang bang dau phan cach doc.
        JPanel actions=new JPanel(new FlowLayout(FlowLayout.LEFT,8,6)); actions.setOpaque(false);
        JButton add=new JButton("▣ Lập hợp đồng mới"), renew=new JButton("↻ Gia hạn hợp đồng"), end=new JButton("■ Kết thúc hợp đồng");
        JButton view=new JButton("👁 Xem hợp đồng"), print=new JButton("🖶 In hợp đồng");
        JButton del=new JButton("✕ Xóa"), clear=new JButton("↻ Làm mới");
        Theme.styleButton(add,Theme.PRIMARY,Color.WHITE); Theme.styleButton(renew,Theme.TEAL,Color.WHITE); Theme.styleButton(end,Theme.ORANGE,Color.WHITE);
        Theme.styleButton(view,Theme.NAVY,Color.WHITE); Theme.styleButton(print,Theme.NAVY,Color.WHITE);
        Theme.styleButton(del,Theme.RED,Color.WHITE); Theme.styleButton(clear,Theme.MUTED,Color.WHITE);
        UIFx.hoverButton(add,Theme.PRIMARY); UIFx.hoverButton(renew,Theme.TEAL); UIFx.hoverButton(end,Theme.ORANGE);
        UIFx.hoverButton(view,Theme.NAVY); UIFx.hoverButton(print,Theme.NAVY);
        UIFx.hoverButton(del,Theme.RED); UIFx.hoverButton(clear,Theme.MUTED);
        actions.add(add); actions.add(renew); actions.add(end);
        actions.add(separator()); actions.add(view); actions.add(print);
        actions.add(separator()); actions.add(del); actions.add(clear);

        // Hang 2: bo loc va tim kiem, tach rieng khoi hang thao tac de de nhin, de dung.
        JPanel filters=new JPanel(new FlowLayout(FlowLayout.LEFT,8,6)); filters.setOpaque(false);
        filters.add(new JLabel("Khu trọ:")); propertyFilter=new JComboBox<>(); propertyFilter.setPreferredSize(new Dimension(170,34)); filters.add(propertyFilter);
        filters.add(new JLabel("Phòng:")); roomFilter=new JComboBox<>(); roomFilter.setPreferredSize(new Dimension(130,34)); filters.add(roomFilter);
        filters.add(new JLabel("Trạng thái:")); statusFilter=new JComboBox<>(new String[]{"Tất cả","Đang thuê","Đã kết thúc"}); statusFilter.setPreferredSize(new Dimension(130,34)); filters.add(statusFilter);
        searchField=new JTextField(15); Theme.styleInput(searchField); UIFx.hoverInput(searchField); filters.add(new JLabel("🔎 Tìm:")); filters.add(searchField);
        countLabel=new JLabel(); countLabel.setFont(new Font("Segoe UI",Font.BOLD,12)); countLabel.setForeground(Theme.MUTED);
        JPanel countWrap=new JPanel(new FlowLayout(FlowLayout.RIGHT,0,6)); countWrap.setOpaque(false); countWrap.add(countLabel);
        JPanel filterRowWrap=new JPanel(new BorderLayout()); filterRowWrap.setOpaque(false); filterRowWrap.add(filters,BorderLayout.CENTER); filterRowWrap.add(countWrap,BorderLayout.EAST);

        add.addActionListener(e->openDialog()); renew.addActionListener(e->renewSelected()); end.addActionListener(e->endSelected()); view.addActionListener(e->viewSelected(false)); print.addActionListener(e->viewSelected(true)); del.addActionListener(e->deleteSelected()); clear.addActionListener(e->{searchField.setText("");statusFilter.setSelectedIndex(0);propertyFilter.setSelectedIndex(0);refresh();});
        propertyFilter.addActionListener(e->refresh()); roomFilter.addActionListener(e->refresh()); statusFilter.addActionListener(e->refresh());
        searchField.getDocument().addDocumentListener(new javax.swing.event.DocumentListener(){public void insertUpdate(javax.swing.event.DocumentEvent e){refresh();}public void removeUpdate(javax.swing.event.DocumentEvent e){refresh();}public void changedUpdate(javax.swing.event.DocumentEvent e){refresh();}});

        wrap.add(actions);
        wrap.add(new JSeparator(SwingConstants.HORIZONTAL));
        wrap.add(filterRowWrap);
        return wrap;
    }

    private Component separator(){
        JSeparator s=new JSeparator(SwingConstants.VERTICAL); s.setPreferredSize(new Dimension(1,26)); s.setForeground(Theme.BORDER); return s;
    }

    private Contract getSelectedContract(){int r=table.getSelectedRow(); if(r<0)return null; int mr=table.convertRowIndexToModel(r); return dm.getContractById(((Number)model.getValueAt(mr,0)).intValue());}
    private Property propertyOf(Contract c){Room r=dm.getRoomById(c.getRoomId()); return r==null?null:dm.getPropertyById(r.getPropertyId());}
    private Room roomOf(Contract c){return dm.getRoomById(c.getRoomId());}
    private Tenant tenantOf(Contract c){return dm.getTenantById(c.getTenantId());}

    private void openDialog(){
        ContractDialog d=new ContractDialog(mainFrame); d.setLocationRelativeTo(mainFrame); d.setVisible(true);
        if(d.isSaved()){Contract c=d.getResult();dm.addContract(c); Tenant t=dm.getTenantById(c.getTenantId()); if(t!=null){t.setRoomId(c.getRoomId());dm.updateTenant(t);} Room r=dm.getRoomById(c.getRoomId()); if(r!=null){r.setStatus(Room.DA_THUE);dm.updateRoom(r);} dm.save();refresh();mainFrame.refreshAll();}
    }
    private void renewSelected(){
        Contract old=getSelectedContract();
        if(old==null){warnNoSelection();return;}
        if(!Contract.DA_KET_THUC.equals(old.getStatus())){
            JOptionPane.showMessageDialog(this,"Chỉ có thể gia hạn hợp đồng đã kết thúc. Hãy kết thúc hợp đồng cũ trước khi gia hạn.");
            return;
        }
        ContractRenewalDialog d=new ContractRenewalDialog(mainFrame,old);
        d.setLocationRelativeTo(mainFrame); d.setVisible(true);
        if(d.isSaved()){
            Contract renewed=d.getResult();
            dm.addContract(renewed);
            Tenant t=dm.getTenantById(renewed.getTenantId());
            if(t!=null){t.setRoomId(renewed.getRoomId());dm.updateTenant(t);}
            Room r=dm.getRoomById(renewed.getRoomId());
            if(r!=null){r.setStatus(Room.DA_THUE);dm.updateRoom(r);}
            dm.save(); refresh(); mainFrame.refreshAll();
            JOptionPane.showMessageDialog(this,"Gia hạn hợp đồng thành công. Hợp đồng cũ vẫn được lưu trong lịch sử.");
        }
    }

    private void endSelected(){Contract c=getSelectedContract(); if(c==null){warnNoSelection();return;} int ok=JOptionPane.showConfirmDialog(this,"Kết thúc hợp đồng #"+c.getId()+"?","Xác nhận",JOptionPane.YES_NO_OPTION); if(ok==JOptionPane.YES_OPTION){dm.endContract(c.getId());dm.save();refresh();mainFrame.refreshAll();}}
    private void viewSelected(boolean print){Contract c=getSelectedContract(); if(c==null){warnNoSelection();return;} ContractDocumentDialog d=new ContractDocumentDialog(mainFrame,c); d.setLocationRelativeTo(mainFrame); d.setVisible(true); if(print) d.printDocument();}
    private void deleteSelected(){Contract c=getSelectedContract(); if(c==null){warnNoSelection();return;} int ok=JOptionPane.showConfirmDialog(this,"Xóa hợp đồng #"+c.getId()+"?","Xác nhận",JOptionPane.YES_NO_OPTION); if(ok==JOptionPane.YES_OPTION){dm.deleteContract(c.getId());dm.save();refresh();mainFrame.refreshAll();}}
    private void warnNoSelection(){JOptionPane.showMessageDialog(this,"Hãy chọn một hợp đồng trước.");}

    private void rebuildRoomFilter(){
        if(roomFilter==null)return; String old=(String)roomFilter.getSelectedItem(); roomFilter.removeAllItems(); roomFilter.addItem("Tất cả phòng"); String pf=(String)propertyFilter.getSelectedItem();
        for(Room r:dm.getRooms()) { Property p=dm.getPropertyById(r.getPropertyId()); if(pf==null||"Tất cả khu trọ".equals(pf)||(p!=null&&pf.equals(p.getName()))) roomFilter.addItem(r.getRoomNumber()); }
        if(old!=null)roomFilter.setSelectedItem(old); if(roomFilter.getSelectedIndex()<0)roomFilter.setSelectedIndex(0); refresh();
    }

    public void refresh(){
        if(model==null||propertyFilter==null)return; String old=(String)propertyFilter.getSelectedItem(); propertyFilter.removeAllItems();propertyFilter.addItem("Tất cả khu trọ"); for(Property p:dm.getProperties())if(p.isActive())propertyFilter.addItem(p.getName()); if(old!=null)propertyFilter.setSelectedItem(old); if(propertyFilter.getSelectedIndex()<0)propertyFilter.setSelectedIndex(0);
        // Avoid rebuilding room filter recursively from property refresh.
        String pf=(String)propertyFilter.getSelectedItem(); if(roomFilter!=null){String ro=(String)roomFilter.getSelectedItem();roomFilter.removeAllItems();roomFilter.addItem("Tất cả phòng");for(Room r:dm.getRooms()){Property p=dm.getPropertyById(r.getPropertyId());if(pf==null||"Tất cả khu trọ".equals(pf)||(p!=null&&pf.equals(p.getName())))roomFilter.addItem(r.getRoomNumber());}if(ro!=null)roomFilter.setSelectedItem(ro);if(roomFilter.getSelectedIndex()<0)roomFilter.setSelectedIndex(0);}
        model.setRowCount(0); String room=(String)roomFilter.getSelectedItem(); String stat=(String)statusFilter.getSelectedItem(); String s=searchField==null?"":searchField.getText().trim().toLowerCase(); DateTimeFormatter f=DateTimeFormatter.ofPattern("dd/MM/yyyy");
        int shown=0;
        for(Contract c:dm.getContracts()){Property p=propertyOf(c);Room r=roomOf(c);Tenant t=tenantOf(c); if(pf!=null&&!"Tất cả khu trọ".equals(pf)&&(p==null||!pf.equals(p.getName())))continue; if(room!=null&&!"Tất cả phòng".equals(room)&&(r==null||!room.equals(r.getRoomNumber())))continue; if(stat!=null&&!"Tất cả".equals(stat)){String want="Đang thuê".equals(stat)?Contract.DANG_THUE:Contract.DA_KET_THUC;if(!want.equals(c.getStatus()))continue;} String hay=((t==null?"":t.getFullName())+" "+(t==null?"":t.getPhone())+" "+(r==null?"":r.getRoomNumber())+" "+(p==null?"":p.getName())).toLowerCase();if(!s.isEmpty()&&!hay.contains(s))continue;
            String statusDisplay=c.getStatus();
            if(Contract.DANG_THUE.equals(c.getStatus())){
                long daysLeft=c.daysUntilExpiry();
                if(daysLeft>=0 && daysLeft<=30) statusDisplay="Sắp hết hạn ("+daysLeft+" ngày)";
            }
            model.addRow(new Object[]{c.getId(),p==null?"Chưa xác định":p.getName(),r==null?"":r.getRoomNumber(),t==null?"":t.getFullName(),c.getStartDate()==null?"":c.getStartDate().format(f),c.getEndDate()==null?"":c.getEndDate().format(f),"Ngày "+c.getPaymentDay()+" hàng tháng",String.format("%,.0f đ",c.getDeposit()),String.format("%,.0f đ",c.getMonthlyRent()),statusDisplay});
            shown++;
        }
        if(countLabel!=null) countLabel.setText(shown+" hợp đồng");
    }
}
