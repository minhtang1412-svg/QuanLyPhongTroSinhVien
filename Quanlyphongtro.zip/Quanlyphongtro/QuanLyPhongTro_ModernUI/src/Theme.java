package com.qlpt.util;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;

/** Global visual theme for the modern professional property-management UI. */
public final class Theme {
    public static final Color PRIMARY = new Color(38, 105, 190);
    public static final Color PRIMARY_DARK = new Color(30, 83, 151);
    public static final Color NAVY = new Color(20, 38, 52);
    public static final Color SIDEBAR = new Color(24, 42, 56);
    public static final Color TEAL = new Color(43, 101, 111);
    public static final Color GREEN = new Color(55, 160, 103);
    public static final Color ORANGE = new Color(235, 143, 60);
    public static final Color PURPLE = new Color(117, 79, 175);
    public static final Color RED = new Color(205, 68, 72);
    public static final Color BG = new Color(246, 248, 251);
    public static final Color CARD = Color.WHITE;
    public static final Color TEXT = new Color(38, 47, 57);
    public static final Color MUTED = new Color(105, 116, 126);
    public static final Color BORDER = new Color(225, 230, 235);

    private Theme() {}

    public static void setup() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}
        Font base = new Font("Segoe UI", Font.PLAIN, 14);
        UIManager.put("defaultFont", base);
        UIManager.put("Label.font", base);
        UIManager.put("Button.font", new Font("Segoe UI", Font.BOLD, 13));
        UIManager.put("TextField.font", base);
        UIManager.put("TextArea.font", base);
        UIManager.put("ComboBox.font", base);
        UIManager.put("Table.font", new Font("Segoe UI", Font.PLAIN, 13));
        UIManager.put("TableHeader.font", new Font("Segoe UI", Font.BOLD, 13));
        UIManager.put("Table.showGrid", false);
        UIManager.put("Table.gridColor", BORDER);
        UIManager.put("Table.selectionBackground", new Color(224, 240, 253));
        UIManager.put("Table.selectionForeground", TEXT);
        UIManager.put("TabbedPane.font", new Font("Segoe UI", Font.BOLD, 13));
        UIManager.put("OptionPane.messageFont", base);
        UIManager.put("OptionPane.buttonFont", new Font("Segoe UI", Font.BOLD, 13));
    }

    public static void styleButton(JButton b, Color bg, Color fg) {
        b.setBackground(bg);
        b.setForeground(fg);
        b.setOpaque(true);
        b.setContentAreaFilled(true);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setBorder(new EmptyBorder(9, 16, 9, 16));
    }

    public static void styleInput(JTextField f) {
        f.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        f.setForeground(TEXT);
        f.setBackground(Color.WHITE);
        f.setCaretColor(PRIMARY);
        f.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(BORDER, 1, true),
                new EmptyBorder(8, 11, 8, 11)));
    }

    public static void styleTable(JTable table) {
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setForeground(TEXT);
        table.setBackground(Color.WHITE);
        table.setSelectionBackground(new Color(224, 240, 253));
        table.setSelectionForeground(TEXT);
        table.setRowHeight(34);
        table.setIntercellSpacing(new Dimension(0, 1));
        table.setShowVerticalLines(false);
        table.setShowHorizontalLines(true);
        table.setGridColor(new Color(236, 239, 242));
        table.setFillsViewportHeight(true);
        table.getTableHeader().setReorderingAllowed(false);
        table.getTableHeader().setPreferredSize(new Dimension(0, 38));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(TEAL);
        table.getTableHeader().setForeground(Color.WHITE);
        table.getTableHeader().setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object value, boolean selected, boolean focus, int row, int col) {
                JLabel l = (JLabel) super.getTableCellRendererComponent(t, value, selected, focus, row, col);
                l.setOpaque(true);
                l.setBackground(TEAL);
                l.setForeground(Color.WHITE);
                l.setFont(new Font("Segoe UI", Font.BOLD, 13));
                l.setBorder(new EmptyBorder(0, 10, 0, 10));
                return l;
            }
        });
    }
}
