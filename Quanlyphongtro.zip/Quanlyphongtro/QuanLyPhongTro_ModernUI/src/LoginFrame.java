package com.qlpt.ui;

import com.qlpt.data.DataManager;
import com.qlpt.model.User;
import com.qlpt.util.Theme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class LoginFrame extends JFrame {
    private final JTextField usernameField = new JTextField();
    private final JPasswordField passwordField = new JPasswordField();
    private final JLabel messageLabel = new JLabel(" ");
    private final JButton loginButton = new JButton("Đăng nhập");

    public LoginFrame() {
        Theme.setup();
        setTitle("Quản lý nhà trọ");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 650);
        setMinimumSize(new Dimension(860, 580));
        setLocationRelativeTo(null);
        setContentPane(buildUI());
        getRootPane().setDefaultButton(loginButton);
    }

    private JPanel buildUI() {
        JPanel root = new JPanel(new GridBagLayout());
        root.setBackground(Theme.BG);

        GridBagConstraints rootGbc = new GridBagConstraints();
        rootGbc.fill = GridBagConstraints.BOTH;
        rootGbc.weighty = 1;
        rootGbc.gridy = 0;

        // Khối giới thiệu bên trái
        JPanel brand = new JPanel(new GridBagLayout());
        brand.setBackground(Theme.SIDEBAR);
        brand.setPreferredSize(new Dimension(390, 650));
        brand.setBorder(new EmptyBorder(55, 55, 45, 55));

        GridBagConstraints b = new GridBagConstraints();
        b.gridx = 0;
        b.anchor = GridBagConstraints.NORTHWEST;
        b.fill = GridBagConstraints.HORIZONTAL;
        b.weightx = 1;

        JLabel icon = new JLabel("⌂");
        icon.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 58));
        icon.setForeground(new Color(128, 203, 196));
        b.gridy = 0;
        brand.add(icon, b);

        JLabel title1 = new JLabel("QUẢN LÝ");
        title1.setFont(new Font("Segoe UI", Font.BOLD, 30));
        title1.setForeground(Color.WHITE);
        b.gridy = 1;
        b.insets = new Insets(8, 0, 0, 0);
        brand.add(title1, b);

        JLabel title2 = new JLabel("PHÒNG TRỌ");
        title2.setFont(new Font("Segoe UI", Font.BOLD, 30));
        title2.setForeground(new Color(128, 203, 196));
        b.gridy = 2;
        b.insets = new Insets(0, 0, 0, 0);
        brand.add(title2, b);

        JLabel desc = new JLabel("<html>Quản lý phòng, khách thuê,<br>hợp đồng và hóa đơn<br>trên một nền tảng.</html>");
        desc.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        desc.setForeground(new Color(225, 235, 242));
        b.gridy = 3;
        b.insets = new Insets(20, 0, 0, 0);
        brand.add(desc, b);

        JLabel footer = new JLabel("Quản lý tập trung • Dễ sử dụng • Hiệu quả");
        footer.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        footer.setForeground(new Color(180, 195, 205));
        b.gridy = 4;
        b.weighty = 1;
        b.anchor = GridBagConstraints.SOUTHWEST;
        b.insets = new Insets(0, 0, 0, 0);
        brand.add(footer, b);

        rootGbc.gridx = 0;
        rootGbc.weightx = 0.42;
        root.add(brand, rootGbc);

        // Vùng đăng nhập: card được căn chính giữa tuyệt đối.
        JPanel right = new JPanel(new GridBagLayout());
        right.setBackground(Theme.BG);
        right.setBorder(new EmptyBorder(35, 50, 35, 50));

        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(Theme.CARD);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Theme.BORDER),
                new EmptyBorder(30, 38, 28, 38)));
        card.setPreferredSize(new Dimension(470, 490));
        card.setMinimumSize(new Dimension(430, 470));

        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.weightx = 1;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(0, 0, 0, 0);

        JLabel heading = new JLabel("Chào mừng trở lại", SwingConstants.CENTER);
        heading.setFont(new Font("Segoe UI", Font.BOLD, 25));
        heading.setForeground(Theme.NAVY);
        c.gridy = 0;
        c.insets = new Insets(0, 0, 6, 0);
        card.add(heading, c);

        JLabel sub = new JLabel("Đăng nhập để tiếp tục quản lý nhà trọ", SwingConstants.CENTER);
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        sub.setForeground(Theme.MUTED);
        c.gridy = 1;
        c.insets = new Insets(0, 0, 26, 0);
        card.add(sub, c);

        JLabel userLabel = label("Tên đăng nhập");
        userLabel.setHorizontalAlignment(SwingConstants.LEFT);
        c.gridy = 2;
        c.insets = new Insets(0, 0, 6, 0);
        card.add(userLabel, c);

        styleInput(usernameField);
        usernameField.setAlignmentX(Component.CENTER_ALIGNMENT);
        c.gridy = 3;
        c.insets = new Insets(0, 0, 15, 0);
        card.add(usernameField, c);

        JLabel passLabel = label("Mật khẩu");
        passLabel.setHorizontalAlignment(SwingConstants.LEFT);
        c.gridy = 4;
        c.insets = new Insets(0, 0, 6, 0);
        card.add(passLabel, c);

        styleInput(passwordField);
        passwordField.setAlignmentX(Component.CENTER_ALIGNMENT);
        c.gridy = 5;
        c.insets = new Insets(0, 0, 6, 0);
        card.add(passwordField, c);

        messageLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        messageLabel.setForeground(Theme.RED);
        messageLabel.setHorizontalAlignment(SwingConstants.LEFT);
        c.gridy = 6;
        c.insets = new Insets(0, 0, 7, 0);
        card.add(messageLabel, c);

        Theme.styleButton(loginButton, Theme.TEAL, Color.WHITE);
        loginButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        loginButton.setPreferredSize(new Dimension(360, 44));
        loginButton.setMinimumSize(new Dimension(360, 44));
        loginButton.setMaximumSize(new Dimension(360, 44));
        loginButton.addActionListener(e -> login());
        UIFx.hoverButton(loginButton, Theme.TEAL);
        c.gridy = 7;
        c.insets = new Insets(0, 0, 7, 0);
        card.add(loginButton, c);

        JButton reset = new JButton("Quên mật khẩu? Đặt lại bằng OTP");
        reset.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        reset.setForeground(Theme.PRIMARY_DARK);
        reset.setContentAreaFilled(false);
        reset.setBorderPainted(false);
        reset.setFocusPainted(false);
        reset.addActionListener(e -> new AccountPanel.PasswordResetDialog(null, null, false).setVisible(true));
        c.gridy = 8;
        c.insets = new Insets(0, 0, 16, 0);
        card.add(reset, c);

        JPanel info = new JPanel(new GridBagLayout());
        info.setBackground(new Color(242, 248, 252));
        info.setBorder(new EmptyBorder(10, 12, 10, 12));
        info.setPreferredSize(new Dimension(360, 72));
        info.setMinimumSize(new Dimension(360, 72));
        info.setMaximumSize(new Dimension(360, 72));

        GridBagConstraints i = new GridBagConstraints();
        i.gridx = 0;
        i.weightx = 1;
        i.fill = GridBagConstraints.HORIZONTAL;
        i.anchor = GridBagConstraints.CENTER;

        JLabel infoTitle = new JLabel("Thông tin đăng nhập mặc định", SwingConstants.CENTER);
        infoTitle.setFont(new Font("Segoe UI", Font.BOLD, 11));
        infoTitle.setForeground(Theme.NAVY);
        i.gridy = 0;
        i.insets = new Insets(0, 0, 4, 0);
        info.add(infoTitle, i);

        JLabel infoText = new JLabel("<html><center>Tài khoản: <b>admin</b> &nbsp; | &nbsp; Mật khẩu: <b>admin123</b><br>Hãy cập nhật số điện thoại trong <b>Tài khoản</b> để dùng OTP.</center></html>", SwingConstants.CENTER);
        infoText.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        infoText.setForeground(Theme.MUTED);
        i.gridy = 1;
        i.insets = new Insets(0, 0, 0, 0);
        info.add(infoText, i);

        c.gridy = 9;
        c.insets = new Insets(0, 0, 0, 0);
        card.add(info, c);

        GridBagConstraints r = new GridBagConstraints();
        r.gridx = 0;
        r.gridy = 0;
        r.weightx = 1;
        r.weighty = 1;
        r.anchor = GridBagConstraints.CENTER;
        right.add(card, r);

        rootGbc.gridx = 1;
        rootGbc.weightx = 0.58;
        root.add(right, rootGbc);
        return root;
    }

    private JLabel label(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.BOLD, 13));
        l.setForeground(Theme.TEXT);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        l.setBorder(new EmptyBorder(0,0,6,0));
        return l;
    }

    private void styleInput(JTextField field) {
        Theme.styleInput(field);
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setAlignmentX(Component.LEFT_ALIGNMENT);
        field.setPreferredSize(new Dimension(340, 42));
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        field.setMinimumSize(new Dimension(200, 42));
    }

    private void login() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        if (username.isEmpty() || password.isEmpty()) {
            messageLabel.setText("Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu.");
            return;
        }
        User user = DataManager.getInstance().authenticate(username, password);
        if (user == null) {
            messageLabel.setText("Tên đăng nhập hoặc mật khẩu không đúng.");
            passwordField.setText("");
            passwordField.requestFocus();
            return;
        }
        dispose();
        SwingUtilities.invokeLater(() -> new MainFrame(user).setVisible(true));
    }

    public static void main(String[] args) {
        Theme.setup();
        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}
