package com.qlpt.ui;

import com.qlpt.data.DataManager;
import com.qlpt.model.CommunicationLog;
import com.qlpt.model.Property;
import com.qlpt.model.Room;
import com.qlpt.model.Tenant;
import com.qlpt.util.Theme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** Thông báo: chọn Khu trọ -> Phòng -> Khách thuê. */
public class CommunicationPanel extends JPanel {
    private final DataManager dm;
    private final MainFrame frame;
    private JTable table;
    private DefaultTableModel model;

    public CommunicationPanel(MainFrame frame) {
        this.frame = frame;
        this.dm = DataManager.getInstance();
        setLayout(new BorderLayout(10, 10));
        setBorder(new EmptyBorder(15, 15, 15, 15));

        JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 5));
        JButton send = new JButton("✉ Ghi nhận gửi Email/SMS");
        JButton detail = new JButton("⌕ Xem nội dung");
        JButton delete = new JButton("✕ Xóa lịch sử");
        send.addActionListener(e -> sendDialog());
        detail.addActionListener(e -> detail());
        delete.addActionListener(e -> deleteSelected());
        toolbar.add(send); toolbar.add(detail); toolbar.add(delete);
        add(toolbar, BorderLayout.NORTH);

        model = new DefaultTableModel(new Object[]{"ID", "Thời gian", "Khu trọ", "Phòng", "Kênh", "Người nhận", "Trạng thái", "Tiêu đề"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);
        Theme.styleTable(table);
        table.setRowHeight(30);
        add(new JScrollPane(table), BorderLayout.CENTER);
        refresh();
    }

    private CommunicationLog selected() {
        int row = table.getSelectedRow();
        if (row < 0) return null;
        int id = ((Integer) model.getValueAt(row, 0));
        for (CommunicationLog log : dm.getCommunicationLogs()) if (log.getId() == id) return log;
        return null;
    }

    private void sendDialog() {
        JComboBox<Property> propertyCombo = new JComboBox<>(dm.getProperties().stream().filter(Property::isActive).toArray(Property[]::new));
        JComboBox<Room> roomCombo = new JComboBox<>();
        JComboBox<Tenant> tenantCombo = new JComboBox<>();
        JComboBox<String> channelCombo = new JComboBox<>(new String[]{CommunicationLog.SMS, CommunicationLog.EMAIL});
        JTextField subject = new JTextField("Nhắc thanh toán tiền phòng");
        JTextArea message = new JTextArea("Kính chào quý khách, đây là thông báo từ hệ thống quản lý nhà trọ về khoản tiền phòng của bạn.", 5, 30);
        message.setLineWrap(true); message.setWrapStyleWord(true);

        Runnable loadRooms = () -> {
            Property p = (Property) propertyCombo.getSelectedItem();
            roomCombo.removeAllItems();
            if (p != null) for (Room r : dm.getRoomsByProperty(p.getId())) roomCombo.addItem(r);
            loadTenants(roomCombo, tenantCombo);
        };
        propertyCombo.addActionListener(e -> loadRooms.run());
        roomCombo.addActionListener(e -> loadTenants(roomCombo, tenantCombo));
        loadRooms.run();

        JPanel form = new JPanel(new BorderLayout(6, 6));
        JPanel fields = new JPanel(new GridLayout(0, 2, 6, 6));
        fields.add(new JLabel("Khu trọ (*):")); fields.add(propertyCombo);
        fields.add(new JLabel("Phòng (*):")); fields.add(roomCombo);
        fields.add(new JLabel("Khách thuê (*):")); fields.add(tenantCombo);
        fields.add(new JLabel("Kênh:")); fields.add(channelCombo);
        fields.add(new JLabel("Tiêu đề:")); fields.add(subject);
        form.add(fields, BorderLayout.NORTH);
        form.add(new JScrollPane(message), BorderLayout.CENTER);

        int result = JOptionPane.showConfirmDialog(this, form, "Gửi Email/SMS", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) return;

        Property property = (Property) propertyCombo.getSelectedItem();
        Room room = (Room) roomCombo.getSelectedItem();
        Tenant tenant = (Tenant) tenantCombo.getSelectedItem();
        if (property == null) { JOptionPane.showMessageDialog(this, "Vui lòng chọn khu trọ."); return; }
        if (room == null) { JOptionPane.showMessageDialog(this, "Vui lòng chọn phòng thuộc khu trọ đã chọn."); return; }
        if (tenant == null) { JOptionPane.showMessageDialog(this, "Phòng đã chọn chưa có khách thuê."); return; }

        CommunicationLog log = new CommunicationLog();
        log.setTenantId(tenant.getId());
        log.setChannel((String) channelCombo.getSelectedItem());
        log.setRecipient(CommunicationLog.SMS.equals(log.getChannel()) ? tenant.getPhone() : tenant.getEmail());
        log.setSubject(subject.getText());
        log.setMessage(message.getText());
        log.setStatus("Đã gửi");
        log.setSentAt(LocalDateTime.now());
        log.setRoomNumber(room.getRoomNumber());
        dm.addCommunicationLog(log);
        refresh();
        JOptionPane.showMessageDialog(this, "Đã ghi nhận gửi " + log.getChannel() + " tới " + log.getRecipient() + ".");
    }

    private void loadTenants(JComboBox<Room> roomCombo, JComboBox<Tenant> tenantCombo) {
        Room room = (Room) roomCombo.getSelectedItem();
        tenantCombo.removeAllItems();
        if (room == null) return;
        for (Tenant t : dm.getTenants()) if (t.getRoomId() != null && t.getRoomId() == room.getId()) tenantCombo.addItem(t);
    }

    private void detail() {
        CommunicationLog log = selected();
        if (log == null) return;
        String text = "Kênh: " + log.getChannel() +
                "\nNgười nhận: " + log.getRecipient() +
                "\nPhòng: " + log.getRoomNumber() +
                "\nThời gian: " + (log.getSentAt() == null ? "" : log.getSentAt().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))) +
                "\nTrạng thái: " + log.getStatus() +
                "\nTiêu đề: " + log.getSubject() +
                "\n\n" + log.getMessage();
        JTextArea area = new JTextArea(text);
        area.setEditable(false); area.setLineWrap(true); area.setWrapStyleWord(true);
        JOptionPane.showMessageDialog(this, new JScrollPane(area), "Nội dung tin nhắn", JOptionPane.INFORMATION_MESSAGE);
    }

    private void deleteSelected() {
        CommunicationLog log = selected();
        if (log == null) return;
        if (JOptionPane.showConfirmDialog(this, "Xóa bản ghi?", "Xác nhận", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            dm.deleteCommunicationLog(log.getId());
            refresh();
        }
    }

    public void refresh() {
        model.setRowCount(0);
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        for (CommunicationLog log : dm.getCommunicationLogs()) {
            Tenant tenant = dm.getTenantById(log.getTenantId());
            String propertyName = "";
            if (tenant != null && tenant.getRoomId() != null) {
                Room r = dm.getRoomById(tenant.getRoomId());
                if (r != null) {
                    Property p = dm.getPropertyById(r.getPropertyId());
                    if (p != null) propertyName = p.getName();
                }
            }
            model.addRow(new Object[]{log.getId(), log.getSentAt() == null ? "" : log.getSentAt().format(fmt), propertyName,
                    log.getRoomNumber(), log.getChannel(), log.getRecipient(), log.getStatus(), log.getSubject()});
        }
    }
}
