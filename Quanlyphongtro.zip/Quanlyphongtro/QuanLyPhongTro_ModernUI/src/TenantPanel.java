package com.qlpt.ui;

import com.qlpt.data.DataManager;
import com.qlpt.model.Property;
import com.qlpt.model.Room;
import com.qlpt.model.Tenant;
import com.qlpt.model.Contract;
import com.qlpt.util.Theme;

import javax.swing.*;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.time.format.DateTimeFormatter;

public class TenantPanel extends JPanel {
    private final MainFrame mainFrame;
    private final DataManager dm;
    private DefaultTableModel model;
    private JTable table;
    private JTextField searchField;
    private JComboBox<String> propertyFilter;
    private JComboBox<String> roomStatusFilter;
    private JLabel countLabel;
    private static final int STATUS_COL = 12;
    private static final int ACTION_COL = 14;

    public TenantPanel(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        this.dm = DataManager.getInstance();
        setLayout(new BorderLayout(12,12));
        setBorder(BorderFactory.createEmptyBorder(18,18,18,18));
        setBackground(Theme.BG);
        add(buildToolbar(), BorderLayout.NORTH);
        model = new DefaultTableModel(new Object[]{"ID","Khu trọ","Phòng","Họ tên","Số điện thoại","CCCD","Email","Địa chỉ","Ngày bắt đầu","Ngày kết thúc","Giá thuê/tháng","Ngày nộp tiền","Trạng thái HĐ","Ghi chú","Thao tác"},0) {
            public boolean isCellEditable(int r,int c){ return c == ACTION_COL; }
        };
        table = new JTable(model);
        Theme.styleTable(table);
        table.setRowHeight(38);
        table.setAutoCreateRowSorter(true);
        applyTableRenderers();
        table.getColumnModel().getColumn(ACTION_COL).setPreferredWidth(125);
        table.getColumnModel().getColumn(ACTION_COL).setMinWidth(115);
        table.getColumnModel().getColumn(ACTION_COL).setMaxWidth(145);
        table.getColumnModel().getColumn(ACTION_COL).setCellRenderer(new ContractButtonRenderer());
        table.getColumnModel().getColumn(ACTION_COL).setCellEditor(new ContractButtonEditor());
        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(Theme.BORDER,1));
        add(scroll, BorderLayout.CENTER);
        refresh();
    }

    private void applyTableRenderers(){
        UIFx.enableRowHover(table);
        int moneyCol=10;
        for(int i=0;i<table.getColumnCount();i++){
            if(i==ACTION_COL) continue;
            if(i==STATUS_COL){ table.getColumnModel().getColumn(i).setCellRenderer(new UIFx.StatusPillRenderer(table)); continue; }
            int align = SwingConstants.LEFT;
            if(i==moneyCol) align=SwingConstants.RIGHT;
            if(i==0) align=SwingConstants.CENTER;
            table.getColumnModel().getColumn(i).setCellRenderer(new UIFx.ZebraCellRenderer(table, align));
        }
    }

    private JPanel buildToolbar() {
        JPanel wrap=new JPanel(); wrap.setOpaque(false); wrap.setLayout(new BoxLayout(wrap,BoxLayout.Y_AXIS));

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT,8,6)); actions.setOpaque(false);
        JButton add = new JButton("＋ Thêm khách thuê");
        JButton edit = new JButton("✎ Sửa");
        JButton del = new JButton("✕ Xóa");
        JButton clear = new JButton("↻ Làm mới");
        Theme.styleButton(add, Theme.TEAL, Color.WHITE);
        Theme.styleButton(edit, Theme.PRIMARY, Color.WHITE);
        Theme.styleButton(del, Theme.RED, Color.WHITE);
        Theme.styleButton(clear, Theme.MUTED, Color.WHITE);
        UIFx.hoverButton(add, Theme.TEAL); UIFx.hoverButton(edit, Theme.PRIMARY);
        UIFx.hoverButton(del, Theme.RED); UIFx.hoverButton(clear, Theme.MUTED);
        actions.add(add); actions.add(edit);
        actions.add(separator()); actions.add(del); actions.add(clear);

        JPanel filters = new JPanel(new FlowLayout(FlowLayout.LEFT,8,6)); filters.setOpaque(false);
        filters.add(new JLabel("Khu trọ:"));
        propertyFilter = new JComboBox<>();
        propertyFilter.setPreferredSize(new Dimension(180,34));
        filters.add(propertyFilter);
        filters.add(new JLabel("Trạng thái phòng:"));
        roomStatusFilter = new JComboBox<>(new String[]{"Tất cả","Đã thuê","Trống","Bảo trì"});
        roomStatusFilter.setPreferredSize(new Dimension(120,34));
        filters.add(roomStatusFilter);
        searchField = new JTextField(16);
        Theme.styleInput(searchField); UIFx.hoverInput(searchField);
        filters.add(new JLabel("🔎 Tìm kiếm:"));
        filters.add(searchField);
        countLabel=new JLabel(); countLabel.setFont(new Font("Segoe UI",Font.BOLD,12)); countLabel.setForeground(Theme.MUTED);
        JPanel countWrap=new JPanel(new FlowLayout(FlowLayout.RIGHT,0,6)); countWrap.setOpaque(false); countWrap.add(countLabel);
        JPanel filterRowWrap=new JPanel(new BorderLayout()); filterRowWrap.setOpaque(false); filterRowWrap.add(filters,BorderLayout.CENTER); filterRowWrap.add(countWrap,BorderLayout.EAST);

        add.addActionListener(e -> openDialog(null));
        edit.addActionListener(e -> { Tenant t=getSelectedTenant(); if(t!=null) openDialog(t); else warnNoSelection(); });
        del.addActionListener(e -> deleteSelected());
        clear.addActionListener(e -> { searchField.setText(""); propertyFilter.setSelectedIndex(0); roomStatusFilter.setSelectedIndex(0); refresh(); });
        propertyFilter.addActionListener(e -> refresh());
        roomStatusFilter.addActionListener(e -> refresh());
        searchField.getDocument().addDocumentListener(new javax.swing.event.DocumentListener(){
            public void insertUpdate(javax.swing.event.DocumentEvent e){refresh();}
            public void removeUpdate(javax.swing.event.DocumentEvent e){refresh();}
            public void changedUpdate(javax.swing.event.DocumentEvent e){refresh();}
        });

        wrap.add(actions);
        wrap.add(new JSeparator(SwingConstants.HORIZONTAL));
        wrap.add(filterRowWrap);
        return wrap;
    }

    private Component separator(){
        JSeparator s=new JSeparator(SwingConstants.VERTICAL); s.setPreferredSize(new Dimension(1,26)); s.setForeground(Theme.BORDER); return s;
    }

    private Tenant getSelectedTenant() {
        int r=table.getSelectedRow();
        if(r<0) return null;
        int modelRow=table.convertRowIndexToModel(r);
        int id=((Number)model.getValueAt(modelRow,0)).intValue();
        return dm.getTenantById(id);
    }

    private Tenant getTenantAtModelRow(int modelRow) {
        if (modelRow < 0 || modelRow >= model.getRowCount()) return null;
        Object idValue = model.getValueAt(modelRow, 0);
        if (!(idValue instanceof Number)) return null;
        return dm.getTenantById(((Number) idValue).intValue());
    }

    private void openDialog(Tenant editing) {
        TenantDialog d=new TenantDialog(mainFrame, editing);
        d.setLocationRelativeTo(mainFrame); d.setVisible(true);
        if(d.isSaved()) {
            Tenant t=d.getResult();
            if(editing==null) dm.addTenant(t); else dm.updateTenant(t);
            dm.save(); refresh(); mainFrame.refreshAll();
        }
    }

    private void openContractForTenant(Tenant tenant) {
        if (tenant == null) return;
        for (Contract c : dm.getContracts()) {
            if (c.getTenantId() == tenant.getId() && Contract.DANG_THUE.equals(c.getStatus())) {
                JOptionPane.showMessageDialog(this,
                        "Khách thuê " + tenant.getFullName() + " đã có hợp đồng đang thuê.",
                        "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
        }
        // Chuyển sang đúng mục Hợp đồng trước, sau đó mở form với khách đã được chọn sẵn.
        mainFrame.showPagePublic("contracts", "Hợp đồng");
        ContractDialog d = new ContractDialog(mainFrame, tenant);
        d.setLocationRelativeTo(mainFrame);
        d.setVisible(true);
        if (d.isSaved()) {
            Contract c = d.getResult();
            dm.addContract(c);
            tenant.setRoomId(c.getRoomId());
            dm.updateTenant(tenant);
            Room r = dm.getRoomById(c.getRoomId());
            if (r != null) {
                r.setStatus(Room.DA_THUE);
                dm.updateRoom(r);
            }
            dm.save();
            mainFrame.refreshAll();
            JOptionPane.showMessageDialog(this, "Đã lập hợp đồng cho " + tenant.getFullName() + ".", "Thành công", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void deleteSelected(){
        Tenant t=getSelectedTenant();
        if(t==null){ warnNoSelection(); return; }
        int ok=JOptionPane.showConfirmDialog(this,"Xóa khách thuê "+t.getFullName()+"?","Xác nhận",JOptionPane.YES_NO_OPTION);
        if(ok==JOptionPane.YES_OPTION){ dm.deleteTenant(t.getId()); dm.save(); refresh(); mainFrame.refreshAll(); }
    }
    private void warnNoSelection(){ JOptionPane.showMessageDialog(this,"Hãy chọn khách thuê trước."); }

    private Property propertyOf(Tenant t){
        if(t==null || t.getRoomId()==null) return null;
        Room r=dm.getRoomById(t.getRoomId());
        return r==null?null:dm.getPropertyById(r.getPropertyId());
    }
    private Room roomOf(Tenant t){ return t.getRoomId()==null?null:dm.getRoomById(t.getRoomId()); }

    public void refresh() {
        if(propertyFilter==null || roomStatusFilter==null || model==null) return;
        String old=(String)propertyFilter.getSelectedItem();
        propertyFilter.removeAllItems(); propertyFilter.addItem("Tất cả khu trọ");
        for(Property p:dm.getProperties()) if(p.isActive()) propertyFilter.addItem(p.getName());
        if(old!=null) propertyFilter.setSelectedItem(old);
        if(propertyFilter.getSelectedIndex()<0) propertyFilter.setSelectedIndex(0);
        model.setRowCount(0);
        String pf=(String)propertyFilter.getSelectedItem();
        String sf=searchField==null?"":searchField.getText().trim().toLowerCase();
        String status=(String)roomStatusFilter.getSelectedItem();
        int shown=0;
        for(Tenant t:dm.getTenants()){
            Property p=propertyOf(t); Room r=roomOf(t);
            if(pf!=null && !"Tất cả khu trọ".equals(pf) && (p==null || !pf.equals(p.getName()))) continue;
            if(status!=null && !"Tất cả".equals(status) && (r==null || !status.equals(r.getStatus()))) continue;
            String hay=(t.getFullName()+" "+t.getPhone()+" "+t.getCccd()+" "+t.getEmail()).toLowerCase();
            if(!sf.isEmpty() && !hay.contains(sf)) continue;
            Contract active=null; for(Contract c:dm.getContracts()){ if(c.getTenantId()==t.getId() && Contract.DANG_THUE.equals(c.getStatus())) { active=c; break; } }
            String sd=active==null||active.getStartDate()==null?"":active.getStartDate().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            String ed=active==null||active.getEndDate()==null?"":active.getEndDate().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            String rent=active==null?"":String.format("%,.0f đ",active.getMonthlyRent());
            String pay=active==null?"":"Ngày "+active.getPaymentDay()+" hàng tháng";
            String hs=active==null?"Chưa có hợp đồng":active.getStatus();
            if(active!=null && Contract.DANG_THUE.equals(active.getStatus())){
                long daysLeft=active.daysUntilExpiry();
                if(daysLeft>=0 && daysLeft<=30) hs="Sắp hết hạn ("+daysLeft+" ngày)";
            }
            model.addRow(new Object[]{t.getId(), p==null?"Chưa xác định":p.getName(), r==null?"Chưa xếp phòng":r.getRoomNumber(), t.getFullName(), t.getPhone(), t.getCccd(), t.getEmail(), t.getAddress(), sd, ed, rent, pay, hs, t.getNote(), "Lập hợp đồng"});
            shown++;
        }
        if(countLabel!=null) countLabel.setText(shown+" khách thuê");
    }

    private class ContractButtonRenderer extends JPanel implements TableCellRenderer {
        private final JLabel label = new JLabel("Lập hợp đồng", SwingConstants.CENTER);

        ContractButtonRenderer() {
            super(new BorderLayout());
            setOpaque(true);
            setBorder(BorderFactory.createEmptyBorder(4, 5, 4, 5));
            label.setOpaque(true);
            label.setFont(new Font("Segoe UI", Font.BOLD, 12));
            label.setForeground(Color.WHITE);
            label.setHorizontalAlignment(SwingConstants.CENTER);
            label.setVerticalAlignment(SwingConstants.CENTER);
            add(label, BorderLayout.CENTER);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            Color bg = isSelected ? Theme.PRIMARY_DARK : Theme.PRIMARY;
            setBackground(UIFx.rowBackground(table, row, isSelected));
            label.setBackground(bg);
            label.setForeground(Color.WHITE);
            label.setText("Lập hợp đồng");
            label.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(Theme.PRIMARY_DARK, 1, true),
                    BorderFactory.createEmptyBorder(7, 8, 7, 8)));
            return this;
        }
    }

    private class ContractButtonEditor extends DefaultCellEditor {
        private final JButton button = new JButton("Lập hợp đồng");
        private int editingRow = -1;

        ContractButtonEditor() {
            super(new JCheckBox());
            button.setUI(new javax.swing.plaf.basic.BasicButtonUI());
            button.setOpaque(true);
            button.setContentAreaFilled(true);
            button.setBorderPainted(true);
            button.setFocusPainted(false);
            button.setEnabled(true);
            button.setRolloverEnabled(false);
            button.setForeground(Color.WHITE);
            button.setBackground(Theme.PRIMARY);
            button.setFont(new Font("Segoe UI", Font.BOLD, 12));
            button.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(Theme.PRIMARY_DARK, 1, true),
                    BorderFactory.createEmptyBorder(7, 10, 7, 10)));
            button.addActionListener((ActionEvent e) -> {
                int row = editingRow;
                fireEditingStopped();
                if (row >= 0) {
                    int modelRow = table.convertRowIndexToModel(row);
                    openContractForTenant(getTenantAtModelRow(modelRow));
                }
            });
        }

        @Override public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            editingRow = row;
            button.setText("Lập hợp đồng");
            return button;
        }
        @Override public Object getCellEditorValue() { return "Lập hợp đồng"; }
    }
}
