package com.qlpt.ui;

import com.qlpt.data.DataManager;
import com.qlpt.model.Contract;
import com.qlpt.model.Property;
import com.qlpt.model.Room;
import com.qlpt.model.Tenant;
import com.qlpt.util.Theme;
import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/** Form gia hạn: giữ nguyên khách/phòng, tạo một hợp đồng mới cho kỳ thuê tiếp theo. */
public class ContractRenewalDialog extends JDialog {
    private final DataManager dm;
    private final Contract oldContract;
    private JTextField startField, endField, depositField, rentField, paymentDayField;
    private JTextArea noteArea, termsArea;
    private Contract result;
    private boolean saved;
    private static final DateTimeFormatter F = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public ContractRenewalDialog(JFrame owner, Contract oldContract) {
        super(owner, "Gia hạn hợp đồng thuê", true);
        this.oldContract = oldContract;
        this.dm = DataManager.getInstance();
        setSize(700, 760);
        setMinimumSize(new Dimension(650, 650));
        setResizable(true);
        buildUI();
    }

    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout(10,10));
        root.setBackground(Theme.BG);
        root.setBorder(BorderFactory.createEmptyBorder(18,24,12,24));

        JLabel title = new JLabel("↻  Gia hạn hợp đồng");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(Theme.NAVY);
        root.add(title, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(7,4,7,4); gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1;
        int row = 0;

        addSection(form, gbc, row++, "Hợp đồng cũ (giữ nguyên)", Theme.NAVY);

        Property p = propertyOf(oldContract);
        Room r = dm.getRoomById(oldContract.getRoomId());
        Tenant t = dm.getTenantById(oldContract.getTenantId());
        addInfo(form, gbc, row++, "Khu trọ:", p == null ? "" : p.getName());
        addInfo(form, gbc, row++, "Phòng:", r == null ? "" : r.getRoomNumber());
        addInfo(form, gbc, row++, "Người thuê:", t == null ? "" : t.getFullName());

        addSection(form, gbc, row++, "Kỳ hạn mới", Theme.TEAL);

        LocalDate start = oldContract.getEndDate() == null ? LocalDate.now() : oldContract.getEndDate().plusDays(1);
        LocalDate end = start.plusMonths(6);
        startField = new JTextField(start.format(F));
        endField = new JTextField(end.format(F));
        depositField = new JTextField(String.valueOf((long) oldContract.getDeposit()));
        rentField = new JTextField(String.valueOf((long) oldContract.getMonthlyRent()));
        paymentDayField = new JTextField(String.valueOf(oldContract.getPaymentDay()));
        noteArea = new JTextArea(3,28); noteArea.setText(oldContract.getNote() == null ? "" : oldContract.getNote());
        termsArea = new JTextArea(8,28); termsArea.setLineWrap(true); termsArea.setWrapStyleWord(true);
        termsArea.setText(oldContract.getTerms() == null || oldContract.getTerms().trim().isEmpty() ? Contract.defaultTerms() : oldContract.getTerms());

        Theme.styleInput(startField); Theme.styleInput(endField); Theme.styleInput(depositField);
        Theme.styleInput(rentField); Theme.styleInput(paymentDayField);
        UIFx.hoverInput(startField, endField, depositField, rentField, paymentDayField);

        addRow(form, gbc, row++, "Ngày bắt đầu (dd/MM/yyyy):", startField);
        addRow(form, gbc, row++, "Ngày kết thúc (dd/MM/yyyy):", endField);
        addRow(form, gbc, row++, "Tiền cọc (đ):", depositField);
        addRow(form, gbc, row++, "Giá thuê/tháng (đ):", rentField);
        addRow(form, gbc, row++, "Ngày nộp tiền hàng tháng (1-28):", paymentDayField);

        addSection(form, gbc, row++, "Ghi chú & điều khoản", Theme.ORANGE);
        addRow(form, gbc, row++, "Ghi chú:", new JScrollPane(noteArea));
        JLabel termsLabel = new JLabel("Điều khoản hợp đồng:");
        gbc.gridx=0; gbc.gridy=row; gbc.weightx=0; gbc.weighty=1; gbc.anchor=GridBagConstraints.NORTHWEST; gbc.fill=GridBagConstraints.HORIZONTAL;
        form.add(termsLabel, gbc);
        gbc.gridx=1; gbc.weightx=1; gbc.fill=GridBagConstraints.BOTH;
        form.add(new JScrollPane(termsArea), gbc);

        JScrollPane scroll = new JScrollPane(form); scroll.setBorder(null); scroll.getVerticalScrollBar().setUnitIncrement(16);
        root.add(scroll, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT,8,0)); buttons.setOpaque(false);
        JButton save = new JButton("✔ Gia hạn"); JButton cancel = new JButton("Hủy");
        Theme.styleButton(save, Theme.TEAL, Color.WHITE); Theme.styleButton(cancel, Theme.MUTED, Color.WHITE);
        UIFx.hoverButton(save, Theme.TEAL); UIFx.hoverButton(cancel, Theme.MUTED);
        buttons.add(save); buttons.add(cancel); root.add(buttons, BorderLayout.SOUTH);
        save.addActionListener(e -> onSave()); cancel.addActionListener(e -> dispose());
        getRootPane().setDefaultButton(save); setContentPane(root);
    }

    private void addSection(JPanel panel, GridBagConstraints base, int row, String title, Color accent){
        GridBagConstraints c=(GridBagConstraints)base.clone();
        c.gridx=0; c.gridy=row; c.gridwidth=2; c.weightx=1; c.insets=new Insets(row==0?0:14,4,4,4);
        panel.add(UIFx.sectionHeader(title, accent), c);
        c.gridwidth=1;
    }

    private void addInfo(JPanel panel, GridBagConstraints base, int row, String label, String value) {
        JLabel v = new JLabel(value);
        v.setFont(new Font("Segoe UI", Font.BOLD, 14));
        v.setForeground(Theme.NAVY);
        addRow(panel, base, row, label, v);
    }
    private void addRow(JPanel panel, GridBagConstraints base, int row, String label, JComponent comp) {
        GridBagConstraints l=(GridBagConstraints)base.clone(); l.gridx=0; l.gridy=row; l.weightx=0; l.weighty=0; l.fill=GridBagConstraints.HORIZONTAL;
        panel.add(new JLabel(label), l);
        GridBagConstraints c=(GridBagConstraints)base.clone(); c.gridx=1; c.gridy=row; c.weightx=1; c.weighty=0; c.fill=GridBagConstraints.HORIZONTAL;
        panel.add(comp,c);
    }
    private Property propertyOf(Contract c) { Room r=dm.getRoomById(c.getRoomId()); return r==null?null:dm.getPropertyById(r.getPropertyId()); }

    private void onSave() {
        if (!Contract.DA_KET_THUC.equals(oldContract.getStatus())) {
            JOptionPane.showMessageDialog(this, "Chỉ có thể gia hạn hợp đồng đã kết thúc."); return;
        }
        try {
            LocalDate start=LocalDate.parse(startField.getText().trim(),F);
            LocalDate end=LocalDate.parse(endField.getText().trim(),F);
            if(end.isBefore(start)){JOptionPane.showMessageDialog(this,"Ngày kết thúc phải sau ngày bắt đầu.");return;}
            double deposit=parseMoney(depositField.getText());
            double rent=parseMoney(rentField.getText());
            int paymentDay=Integer.parseInt(paymentDayField.getText().trim());
            if(paymentDay<1||paymentDay>28) throw new NumberFormatException();
            Contract c=new Contract();
            c.setRoomId(oldContract.getRoomId()); c.setTenantId(oldContract.getTenantId());
            c.setStartDate(start); c.setEndDate(end); c.setDeposit(deposit); c.setMonthlyRent(rent);
            c.setPaymentDay(paymentDay); c.setStatus(Contract.DANG_THUE);
            c.setNote(noteArea.getText().trim()); c.setTerms(termsArea.getText());
            result=c; saved=true; dispose();
        } catch(DateTimeParseException ex){ JOptionPane.showMessageDialog(this,"Ngày phải đúng định dạng dd/MM/yyyy."); }
        catch(NumberFormatException ex){ JOptionPane.showMessageDialog(this,"Tiền thuê, tiền cọc và ngày nộp tiền phải là số hợp lệ."); }
    }
    private double parseMoney(String s){String x=s==null?"":s.trim().replace(".","").replace(",","");return x.isEmpty()?0:Double.parseDouble(x);}
    public boolean isSaved(){return saved;} public Contract getResult(){return result;}
}
