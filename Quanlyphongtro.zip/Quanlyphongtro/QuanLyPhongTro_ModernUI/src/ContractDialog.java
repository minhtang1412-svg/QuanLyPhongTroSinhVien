package com.qlpt.ui;

import com.qlpt.data.DataManager;
import com.qlpt.model.Contract;
import com.qlpt.model.Property;
import com.qlpt.model.Room;
import com.qlpt.model.Tenant;
import com.qlpt.util.Theme;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/** Form lập hợp đồng: Khu trọ -> Phòng -> Người thuê. */
public class ContractDialog extends JDialog {
    private final DataManager dm;
    private final Integer presetTenantId;
    private JComboBox<Property> propertyCombo;
    private JComboBox<Room> roomCombo;
    private JComboBox<Tenant> tenantCombo;
    private JTextField startDateField, endDateField, depositField, rentField, paymentDayField;
    private JTextArea noteArea, termsArea;
    private JLabel tenantInfoLabel;
    private boolean saved;
    private Contract result;
    private static final DateTimeFormatter F = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public ContractDialog(JFrame owner) {
        this(owner, null);
    }

    /** Mở form lập hợp đồng với khách thuê đã được chọn sẵn. */
    public ContractDialog(JFrame owner, Tenant presetTenant) {
        super(owner, "Lập hợp đồng thuê mới", true);
        dm = DataManager.getInstance();
        presetTenantId = presetTenant == null ? null : presetTenant.getId();
        setSize(720, 820);
        setMinimumSize(new Dimension(680, 720));
        setResizable(true);
        buildUI();
    }

    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout(10,10));
        root.setBackground(Theme.BG);
        root.setBorder(BorderFactory.createEmptyBorder(18, 24, 12, 24));

        JLabel title = new JLabel("▣  Lập hợp đồng thuê mới");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(Theme.NAVY);
        root.add(title, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(7, 4, 7, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;
        int row = 0;

        addSection(form, gbc, row++, "Đối tượng thuê", Theme.PRIMARY);

        propertyCombo = new JComboBox<>();
        roomCombo = new JComboBox<>();
        tenantCombo = new JComboBox<>();
        for (Property p : dm.getProperties()) if (p.isActive()) propertyCombo.addItem(p);
        for (Tenant t : dm.getTenants()) tenantCombo.addItem(t);

        propertyCombo.setPreferredSize(new Dimension(320, 34));
        roomCombo.setPreferredSize(new Dimension(320, 34));
        tenantCombo.setPreferredSize(new Dimension(320, 34));

        addRow(form, gbc, row++, "Khu trọ (*):", propertyCombo);
        addRow(form, gbc, row++, "Phòng (*):", roomCombo);

        JPanel tenantChooser = new JPanel(new BorderLayout(6,0));
        tenantChooser.setOpaque(false);
        tenantChooser.add(tenantCombo, BorderLayout.CENTER);
        JButton addTenant = new JButton("＋ Thêm khách thuê");
        Theme.styleButton(addTenant, Theme.PRIMARY, Color.WHITE);
        UIFx.hoverButton(addTenant, Theme.PRIMARY);
        tenantChooser.add(addTenant, BorderLayout.EAST);
        addRow(form, gbc, row++, "Người thuê (*):", tenantChooser);

        tenantInfoLabel = new JLabel();
        tenantInfoLabel.setOpaque(true);
        tenantInfoLabel.setBackground(Color.WHITE);
        tenantInfoLabel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Theme.BORDER),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)));
        tenantInfoLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tenantInfoLabel.setVerticalAlignment(SwingConstants.TOP);
        addRow(form, gbc, row++, "Thông tin khách:", tenantInfoLabel);

        addSection(form, gbc, row++, "Thời hạn & tài chính", Theme.TEAL);

        startDateField = new JTextField(LocalDate.now().format(F));
        endDateField = new JTextField(LocalDate.now().plusMonths(6).format(F));
        depositField = new JTextField();
        rentField = new JTextField();
        paymentDayField = new JTextField("5");
        noteArea = new JTextArea(3, 28);
        termsArea = new JTextArea(9, 28);
        termsArea.setLineWrap(true);
        termsArea.setWrapStyleWord(true);
        termsArea.setText(Contract.defaultTerms());

        Theme.styleInput(startDateField); Theme.styleInput(endDateField); Theme.styleInput(depositField);
        Theme.styleInput(rentField); Theme.styleInput(paymentDayField);
        UIFx.hoverInput(startDateField, endDateField, depositField, rentField, paymentDayField);

        addRow(form, gbc, row++, "Ngày bắt đầu (dd/MM/yyyy):", startDateField);
        addRow(form, gbc, row++, "Ngày kết thúc (dd/MM/yyyy):", endDateField);
        addRow(form, gbc, row++, "Tiền cọc (đ):", depositField);
        addRow(form, gbc, row++, "Giá thuê/tháng (đ):", rentField);
        addRow(form, gbc, row++, "Ngày nộp tiền hàng tháng (1-28):", paymentDayField);

        addSection(form, gbc, row++, "Ghi chú & điều khoản", Theme.ORANGE);
        addRow(form, gbc, row++, "Ghi chú:", new JScrollPane(noteArea));

        JLabel termsLabel = new JLabel("Điều khoản hợp đồng:");
        gbc.gridx=0; gbc.gridy=row; gbc.weightx=0; gbc.anchor=GridBagConstraints.NORTHWEST;
        form.add(termsLabel, gbc);
        gbc.gridx=1; gbc.weightx=1; gbc.weighty=1; gbc.fill=GridBagConstraints.BOTH;
        JScrollPane termsScroll = new JScrollPane(termsArea);
        form.add(termsScroll, gbc);

        JScrollPane formScroll = new JScrollPane(form);
        formScroll.setBorder(null);
        formScroll.getVerticalScrollBar().setUnitIncrement(16);
        root.add(formScroll, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        buttons.setOpaque(false);
        JButton save = new JButton("✔ Lưu");
        JButton cancel = new JButton("Hủy");
        Theme.styleButton(save, Theme.TEAL, Color.WHITE);
        Theme.styleButton(cancel, Theme.MUTED, Color.WHITE);
        UIFx.hoverButton(save, Theme.TEAL);
        UIFx.hoverButton(cancel, Theme.MUTED);
        buttons.add(save); buttons.add(cancel);
        root.add(buttons, BorderLayout.SOUTH);

        propertyCombo.addActionListener(e -> rebuildRooms());
        tenantCombo.addActionListener(e -> updateTenantInfo());
        addTenant.addActionListener(e -> addNewTenant());
        save.addActionListener(e -> onSave());
        cancel.addActionListener(e -> dispose());
        getRootPane().setDefaultButton(save);
        setContentPane(root);

        if (presetTenantId != null) selectTenant(presetTenantId);
        rebuildRooms();
        updateTenantInfo();
    }

    private void addSection(JPanel panel, GridBagConstraints base, int row, String title, Color accent){
        GridBagConstraints c=(GridBagConstraints)base.clone();
        c.gridx=0; c.gridy=row; c.gridwidth=2; c.weightx=1; c.insets=new Insets(row==0?0:14,4,4,4);
        panel.add(UIFx.sectionHeader(title, accent), c);
    }

    private void addRow(JPanel panel, GridBagConstraints base, int row, String label, JComponent comp) {
        GridBagConstraints l = (GridBagConstraints) base.clone();
        l.gridx=0; l.gridy=row; l.weightx=0; l.weighty=0; l.fill=GridBagConstraints.HORIZONTAL;
        panel.add(new JLabel(label), l);
        GridBagConstraints c = (GridBagConstraints) base.clone();
        c.gridx=1; c.gridy=row; c.weightx=1; c.weighty=0; c.fill=GridBagConstraints.HORIZONTAL;
        panel.add(comp, c);
    }

    private void selectTenant(int tenantId) {
        for (int i = 0; i < tenantCombo.getItemCount(); i++) {
            Tenant t = tenantCombo.getItemAt(i);
            if (t != null && t.getId() == tenantId) {
                tenantCombo.setSelectedIndex(i);
                break;
            }
        }
    }

    private void updateTenantInfo() {
        Tenant t = (Tenant) tenantCombo.getSelectedItem();
        if (tenantInfoLabel == null) return;
        if (t == null) {
            tenantInfoLabel.setText("Chưa chọn khách thuê");
            return;
        }
        String email = safe(t.getEmail());
        String address = safe(t.getAddress());
        tenantInfoLabel.setText("<html><b>" + safe(t.getFullName()) + "</b>  •  SĐT: " + safe(t.getPhone())
                + "<br>CCCD: " + safe(t.getCccd()) + "  •  Email: " + email
                + "<br>Địa chỉ: " + address + "</html>");
    }

    private String safe(String s) {
        if (s == null || s.trim().isEmpty()) return "Chưa cập nhật";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    private void rebuildRooms() {
        Property selected = (Property) propertyCombo.getSelectedItem();
        Integer oldId = null;
        Room old = (Room) roomCombo.getSelectedItem();
        if (old != null) oldId = old.getId();
        roomCombo.removeAllItems();
        if (selected != null) {
            for (Room r : dm.getRoomsByProperty(selected.getId())) {
                if (!Room.DA_THUE.equals(r.getStatus())) roomCombo.addItem(r);
            }
        }
        if (oldId != null) {
            for (int i=0;i<roomCombo.getItemCount();i++) if (roomCombo.getItemAt(i).getId()==oldId) { roomCombo.setSelectedIndex(i); break; }
        }
        if (roomCombo.getSelectedIndex()<0 && roomCombo.getItemCount()>0) roomCombo.setSelectedIndex(0);
        Room r=(Room)roomCombo.getSelectedItem();
        if (r!=null && (rentField.getText().trim().isEmpty() || rentField.getText().trim().equals("0"))) rentField.setText(String.valueOf((long)r.getPrice()));
    }

    private void addNewTenant() {
        TenantDialog d = new TenantDialog((JFrame)getOwner(), null);
        d.setLocationRelativeTo(this);
        d.setVisible(true);
        if (d.isSaved()) {
            Tenant t = d.getResult();
            dm.addTenant(t);
            dm.save();
            tenantCombo.addItem(t);
            tenantCombo.setSelectedItem(t);
            updateTenantInfo();
        }
    }

    private void onSave() {
        Property property=(Property)propertyCombo.getSelectedItem();
        Room room=(Room)roomCombo.getSelectedItem();
        Tenant tenant=(Tenant)tenantCombo.getSelectedItem();
        if(property==null){JOptionPane.showMessageDialog(this,"Vui lòng chọn khu trọ.");return;}
        if(room==null){JOptionPane.showMessageDialog(this,"Vui lòng chọn phòng thuộc khu trọ đã chọn.");return;}
        if(tenant==null){JOptionPane.showMessageDialog(this,"Vui lòng chọn người thuê.");return;}
        try {
            LocalDate start=LocalDate.parse(startDateField.getText().trim(),F);
            LocalDate end=LocalDate.parse(endDateField.getText().trim(),F);
            if(end.isBefore(start)){JOptionPane.showMessageDialog(this,"Ngày kết thúc phải sau ngày bắt đầu.");return;}
            double deposit=parseMoney(depositField.getText());
            double rent=parseMoney(rentField.getText());
            int paymentDay=Integer.parseInt(paymentDayField.getText().trim());
            if(paymentDay<1||paymentDay>28) throw new NumberFormatException();
            Contract c=new Contract();
            c.setRoomId(room.getId()); c.setTenantId(tenant.getId()); c.setStartDate(start); c.setEndDate(end);
            c.setDeposit(deposit); c.setMonthlyRent(rent); c.setPaymentDay(paymentDay);
            c.setStatus(Contract.DANG_THUE); c.setNote(noteArea.getText().trim()); c.setTerms(termsArea.getText());
            result=c; saved=true; dispose();
        } catch(DateTimeParseException ex){
            JOptionPane.showMessageDialog(this,"Ngày phải đúng định dạng dd/MM/yyyy.");
        } catch(NumberFormatException ex){
            JOptionPane.showMessageDialog(this,"Tiền thuê, tiền cọc và ngày nộp tiền phải là số hợp lệ.");
        }
    }

    private double parseMoney(String s) { String x=s==null?"":s.trim().replace(".","").replace(",",""); return x.isEmpty()?0:Double.parseDouble(x); }
    public boolean isSaved(){return saved;}
    public Contract getResult(){return result;}
}
