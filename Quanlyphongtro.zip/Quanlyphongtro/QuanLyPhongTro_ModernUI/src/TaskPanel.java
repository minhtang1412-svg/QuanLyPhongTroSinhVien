package com.qlpt.ui;

import com.qlpt.data.DataManager;
import com.qlpt.model.Property;
import com.qlpt.model.Room;
import com.qlpt.util.Theme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;

/** Quản lý công việc: luôn chọn Khu trọ -> Phòng trước khi nhập công việc. */
public class TaskPanel extends JPanel {
    private final DataManager dm;
    private final MainFrame frame;
    private DefaultTableModel model;
    private JTable table;
    private int seq = 1;

    public TaskPanel(MainFrame frame) {
        this.frame = frame;
        this.dm = DataManager.getInstance();
        setLayout(new BorderLayout(10, 10));
        setBorder(new EmptyBorder(15, 15, 15, 15));

        JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        JButton add = new JButton("＋ Thêm công việc");
        JButton done = new JButton("✓ Hoàn thành");
        JButton delete = new JButton("✕ Xóa");
        add.addActionListener(e -> addTask());
        done.addActionListener(e -> markDone());
        delete.addActionListener(e -> deleteSelected());
        toolbar.add(add); toolbar.add(done); toolbar.add(delete);
        add(toolbar, BorderLayout.NORTH);

        model = new DefaultTableModel(new Object[]{"ID", "Khu trọ", "Phòng", "Công việc", "Trạng thái", "Hạn xử lý"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);
        Theme.styleTable(table);
        table.setRowHeight(30);
        add(new JScrollPane(table), BorderLayout.CENTER);
    }

    private void addTask() {
        JComboBox<Property> propertyCombo = new JComboBox<>(dm.getProperties().stream().filter(Property::isActive).toArray(Property[]::new));
        JComboBox<Room> roomCombo = new JComboBox<>();
        JTextField taskField = new JTextField();
        JTextField dueField = new JTextField(LocalDate.now().plusDays(1).toString());

        Runnable loadRooms = () -> {
            Property p = (Property) propertyCombo.getSelectedItem();
            roomCombo.removeAllItems();
            if (p != null) {
                for (Room r : dm.getRoomsByProperty(p.getId())) roomCombo.addItem(r);
            }
        };
        propertyCombo.addActionListener(e -> loadRooms.run());
        loadRooms.run();

        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
        form.add(new JLabel("Khu trọ (*):")); form.add(propertyCombo);
        form.add(new JLabel("Phòng (*):")); form.add(roomCombo);
        form.add(new JLabel("Công việc (*):")); form.add(taskField);
        form.add(new JLabel("Hạn (yyyy-MM-dd):")); form.add(dueField);

        int result = JOptionPane.showConfirmDialog(this, form, "Thêm công việc", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) return;

        Property property = (Property) propertyCombo.getSelectedItem();
        Room room = (Room) roomCombo.getSelectedItem();
        String task = taskField.getText().trim();
        if (property == null) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn khu trọ.");
            return;
        }
        if (room == null) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn phòng thuộc khu trọ đã chọn.");
            return;
        }
        if (task.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập công việc.");
            return;
        }
        try {
            LocalDate.parse(dueField.getText().trim());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Hạn xử lý không đúng định dạng yyyy-MM-dd.");
            return;
        }

        model.addRow(new Object[]{seq++, property.getName(), room.getRoomNumber(), task, "Đang xử lý", dueField.getText().trim()});
    }

    private void markDone() {
        int row = table.getSelectedRow();
        if (row >= 0) model.setValueAt("Đã hoàn thành", row, 4);
    }

    private void deleteSelected() {
        int row = table.getSelectedRow();
        if (row >= 0) model.removeRow(row);
    }
}
