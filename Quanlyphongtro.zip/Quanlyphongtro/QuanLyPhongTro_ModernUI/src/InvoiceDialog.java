package com.qlpt.ui;

import com.qlpt.data.DataManager;
import com.qlpt.model.Contract;
import com.qlpt.model.Invoice;
import com.qlpt.model.Property;
import com.qlpt.model.Room;
import com.qlpt.model.Tenant;
import com.qlpt.util.Formatter;
import com.qlpt.util.Theme;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;

/** Form lập hóa đơn: Khu trọ -> Phòng -> Hợp đồng. */
public class InvoiceDialog extends JDialog {
    private final DataManager dm;
    private JComboBox<Property> propertyCombo;
    private JComboBox<Room> roomCombo;
    private JComboBox<Contract> contractCombo;
    private JTextField monthField;
    private JTextField yearField;
    private JTextField rentField;
    private JTextField oldElecField;
    private JTextField newElecField;
    private JTextField elecPriceField;
    private JTextField oldWaterField;
    private JTextField newWaterField;
    private JTextField waterPriceField;
    private JTextField serviceFeeField;
    private JLabel totalLabel;
    private JLabel dueDateLabel;
    private boolean saved;
    private Invoice result;

    public InvoiceDialog(JFrame owner) {
        super(owner, "Lập hóa đơn mới", true);
        dm = DataManager.getInstance();
        saved = false;
        setSize(620, 700);
        setMinimumSize(new Dimension(580, 650));
        setLocationRelativeTo(owner);
        buildUI();
    }

    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout(10,10));
        root.setBackground(Theme.BG);
        root.setBorder(BorderFactory.createEmptyBorder(16, 20, 12, 20));

        JLabel title = new JLabel("▣  Lập hóa đơn mới");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(Theme.NAVY);
        root.add(title, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 6, 5, 6);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;
        int row = 0;

        propertyCombo = new JComboBox<>();
        roomCombo = new JComboBox<>();
        contractCombo = new JComboBox<>();
        propertyCombo.setPreferredSize(new Dimension(360, 34));
        roomCombo.setPreferredSize(new Dimension(360, 34));
        contractCombo.setPreferredSize(new Dimension(360, 34));
        for (Property p : dm.getProperties()) if (p.isActive()) propertyCombo.addItem(p);

        contractCombo.setRenderer(new DefaultListCellRenderer() {
            @Override public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof Contract) {
                    Contract c = (Contract) value;
                    Room r = dm.getRoomById(c.getRoomId());
                    Tenant t = dm.getTenantById(c.getTenantId());
                    setText((r == null ? "Phòng ?" : "Phòng " + r.getRoomNumber()) + "  •  " + (t == null ? "Chưa xác định" : t.getFullName()));
                }
                return this;
            }
        });

        addRow(form, gbc, row++, "Khu trọ (*):", propertyCombo);
        addRow(form, gbc, row++, "Phòng (*):", roomCombo);
        addRow(form, gbc, row++, "Hợp đồng (*):", contractCombo);

        JPanel period = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        period.setOpaque(false);
        monthField = new JTextField(String.valueOf(LocalDate.now().getMonthValue()), 5);
        yearField = new JTextField(String.valueOf(LocalDate.now().getYear()), 6);
        Theme.styleInput(monthField); Theme.styleInput(yearField);
        period.add(new JLabel("Tháng:")); period.add(monthField);
        period.add(new JLabel("Năm:")); period.add(yearField);
        addRow(form, gbc, row++, "Kỳ hóa đơn:", period);

        rentField = new JTextField(10);
        oldElecField = new JTextField("0", 8);
        newElecField = new JTextField("0", 8);
        elecPriceField = new JTextField("3500", 8);
        oldWaterField = new JTextField("0", 8);
        newWaterField = new JTextField("0", 8);
        waterPriceField = new JTextField("20000", 8);
        serviceFeeField = new JTextField("0", 10);
        Theme.styleInput(rentField); Theme.styleInput(oldElecField); Theme.styleInput(newElecField);
        Theme.styleInput(elecPriceField); Theme.styleInput(oldWaterField); Theme.styleInput(newWaterField);
        Theme.styleInput(waterPriceField); Theme.styleInput(serviceFeeField);
        UIFx.hoverInput(rentField, oldElecField, newElecField, elecPriceField, oldWaterField, newWaterField, waterPriceField, serviceFeeField);

        addRow(form, gbc, row++, "Tiền phòng (đ):", rentField);
        dueDateLabel = new JLabel("—");
        addRow(form, gbc, row++, "Hạn nộp:", dueDateLabel);

        JPanel elec = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0)); elec.setOpaque(false);
        elec.add(new JLabel("Cũ:")); elec.add(oldElecField);
        elec.add(new JLabel("Mới:")); elec.add(newElecField);
        elec.add(new JLabel("Đơn giá:")); elec.add(elecPriceField);
        addRow(form, gbc, row++, "Chỉ số điện (kWh):", elec);

        JPanel water = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0)); water.setOpaque(false);
        water.add(new JLabel("Cũ:")); water.add(oldWaterField);
        water.add(new JLabel("Mới:")); water.add(newWaterField);
        water.add(new JLabel("Đơn giá:")); water.add(waterPriceField);
        addRow(form, gbc, row++, "Chỉ số nước (m³):", water);
        addRow(form, gbc, row++, "Phí dịch vụ khác (đ):", serviceFeeField);

        totalLabel = new JLabel("0 đ");
        totalLabel.setFont(new Font("Segoe UI", Font.BOLD, 17));
        totalLabel.setForeground(Theme.TEAL);
        addRow(form, gbc, row++, "Tổng cộng:", totalLabel);

        JScrollPane scroll = new JScrollPane(form);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        root.add(scroll, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        buttons.setOpaque(false);
        JButton save = new JButton("✔ Lưu");
        JButton cancel = new JButton("Hủy");
        Theme.styleButton(save, Theme.TEAL, Color.WHITE);
        Theme.styleButton(cancel, Theme.MUTED, Color.WHITE);
        UIFx.hoverButton(save, Theme.TEAL); UIFx.hoverButton(cancel, Theme.MUTED);
        buttons.add(save); buttons.add(cancel);
        root.add(buttons, BorderLayout.SOUTH);

        propertyCombo.addActionListener(e -> rebuildRooms());
        roomCombo.addActionListener(e -> rebuildContracts());
        contractCombo.addActionListener(e -> onContractChange());
        monthField.addActionListener(e -> updateDueDate());
        yearField.addActionListener(e -> updateDueDate());
        save.addActionListener(e -> onSave());
        cancel.addActionListener(e -> dispose());
        getRootPane().setDefaultButton(save);
        setContentPane(root);

        // Đồng bộ dữ liệu ngay khi mở form.
        rebuildRooms();
    }

    private void addRow(JPanel panel, GridBagConstraints base, int row, String label, JComponent comp) {
        GridBagConstraints l = (GridBagConstraints) base.clone();
        l.gridx = 0; l.gridy = row; l.weightx = 0; l.weighty = 0;
        panel.add(new JLabel(label), l);
        GridBagConstraints c = (GridBagConstraints) base.clone();
        c.gridx = 1; c.gridy = row; c.weightx = 1;
        panel.add(comp, c);
    }

    private List<Contract> activeContracts() {
        return dm.getActiveContracts();
    }

    private Property propertyOf(Room room) {
        return room == null ? null : dm.getPropertyById(room.getPropertyId());
    }

    private void rebuildRooms() {
        Property selected = (Property) propertyCombo.getSelectedItem();
        int oldRoomId = -1;
        Room old = (Room) roomCombo.getSelectedItem();
        if (old != null) oldRoomId = old.getId();

        List<Integer> activeRoomIds = new ArrayList<>();
        for (Contract c : activeContracts()) activeRoomIds.add(c.getRoomId());

        roomCombo.removeAllItems();
        if (selected != null) {
            for (Room r : dm.getRoomsByProperty(selected.getId())) {
                if (activeRoomIds.contains(r.getId())) roomCombo.addItem(r);
            }
        }
        if (oldRoomId >= 0) selectRoom(oldRoomId);
        if (roomCombo.getSelectedIndex() < 0 && roomCombo.getItemCount() > 0) roomCombo.setSelectedIndex(0);
        rebuildContracts();
    }

    private void selectRoom(int roomId) {
        for (int i = 0; i < roomCombo.getItemCount(); i++) {
            Room r = roomCombo.getItemAt(i);
            if (r != null && r.getId() == roomId) { roomCombo.setSelectedIndex(i); return; }
        }
    }

    private void rebuildContracts() {
        int oldId = -1;
        Contract old = (Contract) contractCombo.getSelectedItem();
        if (old != null) oldId = old.getId();
        contractCombo.removeAllItems();
        Room selectedRoom = (Room) roomCombo.getSelectedItem();
        if (selectedRoom != null) {
            for (Contract c : activeContracts()) if (c.getRoomId() == selectedRoom.getId()) contractCombo.addItem(c);
        }
        if (oldId >= 0) {
            for (int i=0;i<contractCombo.getItemCount();i++) if (contractCombo.getItemAt(i).getId()==oldId) { contractCombo.setSelectedIndex(i); break; }
        }
        if (contractCombo.getSelectedIndex() < 0 && contractCombo.getItemCount() > 0) contractCombo.setSelectedIndex(0);
        onContractChange();
    }

    private void onContractChange() {
        Contract c = (Contract) contractCombo.getSelectedItem();
        if (c == null) {
            rentField.setText("");
            recalc();
            updateDueDate();
            return;
        }
        rentField.setText(String.valueOf((long)c.getMonthlyRent()));

        Invoice latest = null;
        for (Invoice inv : dm.getInvoices()) {
            if (inv.getContractId() != c.getId()) continue;
            if (latest == null || inv.getYear() > latest.getYear() || (inv.getYear() == latest.getYear() && inv.getMonth() > latest.getMonth())) latest = inv;
        }
        if (latest != null) {
            oldElecField.setText(String.valueOf((long)latest.getNewElectric()));
            oldWaterField.setText(String.valueOf((long)latest.getNewWater()));
        } else {
            oldElecField.setText("0");
            oldWaterField.setText("0");
        }
        recalc();
        updateDueDate();
    }

    private void updateDueDate() {
        try {
            Contract c = (Contract) contractCombo.getSelectedItem();
            int month = Integer.parseInt(monthField.getText().trim());
            int year = Integer.parseInt(yearField.getText().trim());
            if (c != null && month >= 1 && month <= 12) {
                int day = Math.min(c.getPaymentDay(), YearMonth.of(year, month).lengthOfMonth());
                dueDateLabel.setText(Formatter.date(LocalDate.of(year, month, day)) + " (ngày " + c.getPaymentDay() + ")");
            } else dueDateLabel.setText("—");
        } catch (Exception ex) {
            dueDateLabel.setText("—");
        }
    }

    private void recalc() {
        try {
            double rent = Formatter.parseMoney(rentField.getText());
            double oldE = parseNum(oldElecField.getText());
            double newE = parseNum(newElecField.getText());
            double ePrice = Formatter.parseMoney(elecPriceField.getText());
            double oldW = parseNum(oldWaterField.getText());
            double newW = parseNum(newWaterField.getText());
            double wPrice = Formatter.parseMoney(waterPriceField.getText());
            double service = Formatter.parseMoney(serviceFeeField.getText());
            double eAmount = Math.max(0, newE - oldE) * ePrice;
            double wAmount = Math.max(0, newW - oldW) * wPrice;
            totalLabel.setText(Formatter.money(rent + eAmount + wAmount + service));
        } catch (Exception ex) {
            totalLabel.setText("(giá trị không hợp lệ)");
        }
    }

    private double parseNum(String s) {
        if (s == null || s.trim().isEmpty()) return 0;
        return Double.parseDouble(s.trim().replaceAll("[^0-9.]", ""));
    }

    private void onSave() {
        Contract c = (Contract) contractCombo.getSelectedItem();
        if (c == null) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn khu trọ, phòng và hợp đồng.", "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            Invoice inv = new Invoice();
            inv.setContractId(c.getId());
            inv.setMonth(Integer.parseInt(monthField.getText().trim()));
            inv.setYear(Integer.parseInt(yearField.getText().trim()));
            if (inv.getMonth() < 1 || inv.getMonth() > 12) throw new NumberFormatException();
            inv.setRentAmount(Formatter.parseMoney(rentField.getText()));
            inv.setOldElectric(parseNum(oldElecField.getText()));
            inv.setNewElectric(parseNum(newElecField.getText()));
            inv.setElectricUnitPrice(Formatter.parseMoney(elecPriceField.getText()));
            inv.setOldWater(parseNum(oldWaterField.getText()));
            inv.setNewWater(parseNum(newWaterField.getText()));
            inv.setWaterUnitPrice(Formatter.parseMoney(waterPriceField.getText()));
            inv.setServiceFee(Formatter.parseMoney(serviceFeeField.getText()));
            inv.setStatus(Invoice.CHUA_THANH_TOAN);
            inv.setCreatedDate(LocalDate.now());
            int day = Math.min(c.getPaymentDay(), YearMonth.of(inv.getYear(), inv.getMonth()).lengthOfMonth());
            inv.setDueDate(LocalDate.of(inv.getYear(), inv.getMonth(), day));
            if (inv.getNewElectric() < inv.getOldElectric()) {
                JOptionPane.showMessageDialog(this, "Chỉ số điện mới phải >= chỉ số cũ.", "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (inv.getNewWater() < inv.getOldWater()) {
                JOptionPane.showMessageDialog(this, "Chỉ số nước mới phải >= chỉ số cũ.", "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }
            result = inv;
            saved = true;
            dispose();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Vui lòng kiểm tra lại các giá trị số đã nhập.", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean isSaved() { return saved; }
    public Invoice getResult() { return result; }
}
