package com.tromanager.service;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.UUID;
import java.util.prefs.Preferences;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class AccountServiceTest {
    private Preferences preferences;

    @Before
    public void setUp() throws Exception {
        preferences = Preferences.userRoot().node("com/tromanager/tests/" + UUID.randomUUID());
    }

    @After
    public void tearDown() throws Exception {
        preferences.removeNode();
        Preferences.userRoot().flush();
    }

    @Test
    public void acceptsDefaultCredentialsOnFirstRun() {
        AccountService account = new AccountService(preferences);

        assertTrue(account.authenticate("admin", "admin123"));
        assertFalse(account.wereCredentialsRecovered());
    }

    @Test
    public void recoversWhenStoredCredentialsAreMalformed() {
        preferences.put("passwordSalt", "not-base64!");
        preferences.put("passwordHash", "not-base64!");
        AccountService account = new AccountService(preferences);

        assertTrue(account.wereCredentialsRecovered());
        assertTrue(account.authenticate("admin", "admin123"));
        assertFalse(account.authenticate("admin", "wrong-password"));
    }

    @Test
    public void changedPasswordSurvivesReload() {
        AccountService account = new AccountService(preferences);
        assertTrue(account.updatePassword("admin123", "new-password", "new-password"));

        AccountService reloaded = new AccountService(preferences);

        assertTrue(reloaded.authenticate("admin", "new-password"));
        assertFalse(reloaded.authenticate("admin", "admin123"));
    }

    @Test
    public void forgottenPasswordCanBeResetAndUsed() {
        AccountService account = new AccountService(preferences);
        String temporaryPassword = account.resetPassword(" admin ");

        assertNotNull(temporaryPassword);
        assertTrue(account.authenticate("admin", temporaryPassword));
    }
}
