package com.tromanager.service;

import com.tromanager.model.Asset;
import com.tromanager.model.Contract;
import com.tromanager.model.Invoice;
import com.tromanager.model.MessageItem;
import com.tromanager.model.RevenueData;
import com.tromanager.model.Room;
import com.tromanager.model.RoomStatus;
import com.tromanager.model.TaskItem;
import com.tromanager.model.Tenant;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class ExcelExportServiceTest {
    @Rule
    public TemporaryFolder temporaryFolder = new TemporaryFolder();

    @Test
    public void exportsWorkbookWithSheetsAndReadableTableData() throws Exception {
        Room room = new Room("1", "P.101", 1, "Khu trọ", RoomStatus.RENTED, "Nguyễn Văn An",
                "0900000000", "01/01/2026", "01/01/2027", 3500000, 3500, 25000, 25,
                Collections.singletonList("Wifi"));
        DataStore.Snapshot snapshot = new DataStore.Snapshot(
                Collections.singletonList(room),
                Collections.singletonList(new Tenant("KT01", "Nguyễn Văn An", "0900000000", "P.101",
                        "012345678901", "Hà Nội", "01/01/2026", 3500000, true)),
                Collections.singletonList(new Contract("HD-101", "P.101", "Nguyễn Văn An", "0900000000",
                        "01/01/2026", "01/01/2027", 3500000, 3500000, 365, Contract.Status.ACTIVE)),
                Collections.singletonList(new Invoice("INV-101", "P.101", "Nguyễn Văn An", "Tháng 08/2026",
                        3500000, 35000, 25000, 0, "05/09/2026", Invoice.InvoiceStatus.UNPAID)),
                Collections.singletonList(new Asset("TS-001", "Điều hòa", "P.101", "Điện lạnh", 1,
                        8500000, "01/01/2026", Asset.AssetStatus.GOOD)),
                Collections.singletonList(new TaskItem("Sửa vòi nước", "P.101", "Hôm nay",
                        TaskItem.Priority.HIGH)),
                Collections.singletonList(new RevenueData("T8/26", 3.5)),
                Collections.singletonList(new MessageItem("Chủ nhà", "P.101", "Đã nhận", "10:00", true, false)));
        Path excelFile = temporaryFolder.getRoot().toPath().resolve("tromanager.xlsx");

        new ExcelExportService().export(snapshot, excelFile);

        assertTrue(Files.size(excelFile) > 0);
        try (InputStream input = Files.newInputStream(excelFile);
             org.apache.poi.ss.usermodel.Workbook workbook = WorkbookFactory.create(input)) {
            assertEquals(9, workbook.getNumberOfSheets());
            assertEquals("P.101", workbook.getSheet("Phòng").getRow(1).getCell(1).getStringCellValue());
            assertEquals("Nguyễn Văn An",
                    workbook.getSheet("Khách thuê").getRow(1).getCell(1).getStringCellValue());
            assertEquals(3500000,
                    workbook.getSheet("Hóa đơn").getRow(1).getCell(6).getNumericCellValue(), 0);
            assertEquals("Chỉ số cũ",
                    workbook.getSheet("CT hóa đơn").getRow(0).getCell(5).getStringCellValue());
        }
    }
}
