package com.tromanager.service;

import com.tromanager.model.Asset;
import com.tromanager.model.Contract;
import com.tromanager.model.Invoice;
import com.tromanager.model.InvoiceDetail;
import com.tromanager.model.MessageItem;
import com.tromanager.model.RevenueData;
import com.tromanager.model.Room;
import com.tromanager.model.RoomStatus;
import com.tromanager.model.TaskItem;
import com.tromanager.model.Tenant;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;

public class DataStoreTest {
    @Rule
    public TemporaryFolder temporaryFolder = new TemporaryFolder();

    @Test
    public void savesLoadsAndExportsEveryDataType() throws Exception {
        DataStore store = new DataStore(temporaryFolder.getRoot().toPath().resolve("data.dat"));
        DataStore.Snapshot expected = sampleSnapshot();

        store.save(expected);
        DataStore.Snapshot loaded = store.load();
        assertNotNull(loaded);
        assertEquals("P.101", loaded.rooms.get(0).getName());
        assertEquals("Nguyễn Văn An", loaded.tenants.get(0).getName());
        assertEquals("HD-101", loaded.contracts.get(0).getCode());
        assertEquals("INV-101", loaded.invoices.get(0).getCode());
        assertEquals(1, loaded.invoices.get(0).getDetails().size());
        assertEquals("TS-001", loaded.assets.get(0).getCode());
        assertEquals("Sửa vòi nước", loaded.tasks.get(0).getTitle());
        assertEquals("T8/26", loaded.revenueData.get(0).getMonth());
        assertEquals("Đã nhận", loaded.messages.get(0).getContent());

        loaded.rooms.get(0).setName("P.102");
        store.save(loaded);
        assertEquals("P.102", store.load().rooms.get(0).getName());

        Path backup = temporaryFolder.getRoot().toPath().resolve("backup.dat");
        store.exportBackup(loaded, backup);
        assertEquals("P.102", store.readBackup(backup).rooms.get(0).getName());
    }

    @Test
    public void rejectsInvalidBackupWithoutChangingPrimaryData() throws Exception {
        Path dataFile = temporaryFolder.getRoot().toPath().resolve("data.dat");
        DataStore store = new DataStore(dataFile);
        store.save(sampleSnapshot());
        byte[] originalData = Files.readAllBytes(dataFile);

        Path invalidBackup = temporaryFolder.getRoot().toPath().resolve("invalid.dat");
        Files.writeString(invalidBackup, "not a TroManager backup");

        assertThrows(IOException.class, () -> store.readBackup(invalidBackup));
        assertArrayEquals(originalData, Files.readAllBytes(dataFile));
    }

    @Test
    public void doesNotAllowBackupToOverwriteTheActiveDataFile() throws Exception {
        Path dataFile = temporaryFolder.getRoot().toPath().resolve("data.dat");
        DataStore store = new DataStore(dataFile);
        store.save(sampleSnapshot());
        byte[] originalData = Files.readAllBytes(dataFile);

        assertThrows(IOException.class, () -> store.exportBackup(sampleSnapshot(), dataFile));
        assertArrayEquals(originalData, Files.readAllBytes(dataFile));
    }

    private static DataStore.Snapshot sampleSnapshot() {
        Room room = new Room("1", "P.101", 1, "Khu trọ", RoomStatus.RENTED, "Nguyễn Văn An",
                "0900000000", "01/01/2026", "01/01/2027", 3500000, 3500, 25000, 25,
                Arrays.asList("Wifi", "WC riêng"));
        Tenant tenant = new Tenant("KT01", "Nguyễn Văn An", "0900000000", "P.101", "012345678901",
                "Hà Nội", "01/01/2026", 3500000, true);
        Contract contract = new Contract("HD-101", "P.101", "Nguyễn Văn An", "0900000000",
                "01/01/2026", "01/01/2027", 3500000, 3500000, 365, Contract.Status.ACTIVE);
        Invoice invoice = new Invoice("INV-101", "P.101", "Nguyễn Văn An", "Tháng 08/2026",
                3500000, 35000, 25000, 0, "05/09/2026", Invoice.InvoiceStatus.UNPAID);
        invoice.getDetails().add(new InvoiceDetail(1, "Tiền phòng", 0, 0, 1, 3500000, 3500000, ""));

        return new DataStore.Snapshot(
                Collections.singletonList(room),
                Collections.singletonList(tenant),
                Collections.singletonList(contract),
                Collections.singletonList(invoice),
                Collections.singletonList(new Asset("TS-001", "Điều hòa", "P.101", "Điện lạnh", 1,
                        8500000, "01/01/2026", Asset.AssetStatus.GOOD)),
                Collections.singletonList(new TaskItem("Sửa vòi nước", "P.101", "Hôm nay",
                        TaskItem.Priority.HIGH)),
                Collections.singletonList(new RevenueData("T8/26", 3.5)),
                Collections.singletonList(new MessageItem("Chủ nhà", "P.101", "Đã nhận", "10:00", true, false)));
    }
}
