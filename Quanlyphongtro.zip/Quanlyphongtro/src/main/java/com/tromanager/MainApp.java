package com.tromanager;
import com.tromanager.controller.DialogHelper;
import com.tromanager.service.MockDataService;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;

import java.io.IOException;

public final class MainApp {

    private MainApp() {
    }

    public static void main(String[] args) {
        Application.launch(TroManagerApplication.class, args);
    }

    public static class TroManagerApplication extends Application {
        private MockDataService dataService;

        @Override
        public void start(Stage primaryStage) {
            try {
                if (!DialogHelper.showLoginDialog()) {
                    Platform.exit();
                    return;
                }

                dataService = MockDataService.getInstance();
                FXMLLoader loader = new FXMLLoader(
                        TroManagerApplication.class.getResource("/com/tromanager/fxml/main_layout.fxml"));
                Parent root = loader.load();

                Scene scene = new Scene(root, 1380, 850);
                scene.getStylesheets().add(TroManagerApplication.class
                        .getResource("/com/tromanager/css/styles.css").toExternalForm());

                primaryStage.setTitle("TroManager - Phần Mềm Quản Lý Phòng Trọ");
                primaryStage.setMinWidth(1100);
                primaryStage.setMinHeight(720);
                primaryStage.setScene(scene);
                primaryStage.show();
            } catch (Exception e) {
                e.printStackTrace();
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("TroManager");
                alert.setHeaderText("Không thể khởi động ứng dụng");
                alert.setContentText(e.getMessage() == null ? "Đã xảy ra lỗi khi tải ứng dụng." : e.getMessage());
                alert.showAndWait();
            }
        }

        @Override
        public void stop() {
            if (dataService == null) return;
            try {
                dataService.saveData();
            } catch (IOException ex) {
                System.err.println("Không thể lưu dữ liệu khi đóng ứng dụng: " + ex.getMessage());
            }
        }
    }
}
