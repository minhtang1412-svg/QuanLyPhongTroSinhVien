package com.tromanager.controller;

import com.tromanager.service.AccountService;
import com.tromanager.service.MockDataService;
import com.tromanager.service.SettingsService;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.FileChooser;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class SettingsController {
    private final SettingsService settings = SettingsService.getInstance();
    private final MockDataService dataService = MockDataService.getInstance();

    @FXML private Button btnResetSettings;
    @FXML private Button btnSaveSettings;
    @FXML private Button btnChangePassword;
    @FXML private Button btnBackupData;
    @FXML private Button btnRestoreData;
    @FXML private Button btnExportExcel;
    @FXML private Label lblDataFileLocation;

    @FXML private TextField txtBuildingName;
    @FXML private TextField txtOwnerName;
    @FXML private TextField txtAddress;
    @FXML private TextField txtPhone;

    @FXML private TextField txtElectricityPrice;
    @FXML private TextField txtWaterPrice;
    @FXML private TextField txtWifiPrice;
    @FXML private TextField txtGarbagePrice;
    @FXML private TextField txtParkingPrice;
    @FXML private ComboBox<String> cbWaterType;

    @FXML private ComboBox<String> cbBankName;
    @FXML private TextField txtBankNumber;
    @FXML private TextField txtBankHolder;

    @FXML private TextField txtBillingDay;
    @FXML private TextField txtIssueDay;
    @FXML private TextField txtDueDay;

    @FXML
    public void initialize() {
        cbWaterType.getItems().addAll("Theo chỉ số khối (m³)", "Theo đầu người (người/tháng)", "Trọn gói theo phòng");
        cbWaterType.setValue("Theo chỉ số khối (m³)");

        cbBankName.getItems().addAll("Techcombank", "Vietcombank", "MB Bank", "BIDV", "VietinBank", "ACB");
        cbBankName.setValue("Techcombank");

        loadSettings();
        lblDataFileLocation.setText("Dữ liệu được lưu tự động tại: " + dataService.getDataFile());

        btnSaveSettings.setOnAction(e -> {
            AccountService.getInstance().setDisplayName(txtOwnerName.getText());
            saveSettings();
            DialogHelper.showInfo("Lưu cấu hình", "Cập nhật thành công!", "Toàn bộ thông tin khu trọ, đơn giá dịch vụ điện nước và tài khoản thanh toán đã được lưu vào hệ thống.");
        });

        btnChangePassword.setOnAction(e -> DialogHelper.showChangePasswordDialog());
        btnBackupData.setOnAction(e -> backupData());
        btnRestoreData.setOnAction(e -> restoreData());
        btnExportExcel.setOnAction(e -> exportExcel());

        btnResetSettings.setOnAction(e -> {
            txtElectricityPrice.setText("3500");
            txtWaterPrice.setText("25000");
            txtWifiPrice.setText("50000");
            txtGarbagePrice.setText("30000");
            txtParkingPrice.setText("100000");
            DialogHelper.showInfo("Khôi phục", "Khôi phục mặc định", "Đã đặt lại đơn giá điện nước về mức tiêu chuẩn.");
        });
    }

    private void backupData() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Sao lưu dữ liệu TroManager");
        chooser.setInitialFileName("tromanager-backup-"
                + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss")) + ".dat");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Bản sao lưu TroManager (*.dat)", "*.dat"));
        File file = chooser.showSaveDialog(btnBackupData.getScene().getWindow());
        if (file == null) return;

        try {
            dataService.exportBackup(file.toPath());
            DialogHelper.showInfo("Sao lưu dữ liệu", "Đã tạo bản sao lưu",
                    "Bản sao lưu đã được lưu tại:\n" + file.getAbsolutePath());
        } catch (IOException ex) {
            DialogHelper.showInfo("Lỗi sao lưu", "Không thể tạo bản sao lưu", ex.getMessage());
        }
    }

    private void restoreData() {
        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
        confirmation.setTitle("Khôi phục dữ liệu");
        confirmation.setHeaderText("Dữ liệu hiện tại sẽ được thay thế");
        confirmation.setContentText("Hãy chắc chắn bạn đã sao lưu dữ liệu hiện tại trước khi tiếp tục.");
        if (confirmation.showAndWait().orElse(ButtonType.CANCEL) != ButtonType.OK) return;

        FileChooser chooser = new FileChooser();
        chooser.setTitle("Chọn bản sao lưu để khôi phục");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Bản sao lưu TroManager (*.dat)", "*.dat"));
        File file = chooser.showOpenDialog(btnRestoreData.getScene().getWindow());
        if (file == null) return;

        try {
            dataService.restoreBackup(file.toPath());
            MainController.refreshCurrentView();
            DialogHelper.showInfo("Khôi phục dữ liệu", "Đã khôi phục thành công",
                    "Dữ liệu từ bản sao lưu đã được nạp vào ứng dụng.");
        } catch (IOException ex) {
            DialogHelper.showInfo("Lỗi khôi phục", "Không thể khôi phục bản sao lưu",
                    "Dữ liệu hiện tại vẫn được giữ nguyên. Chi tiết: " + ex.getMessage());
        }
    }

    private void exportExcel() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Xuất dữ liệu TroManager ra Excel");
        chooser.setInitialFileName("tromanager-data-"
                + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss")) + ".xlsx");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Excel Workbook (*.xlsx)", "*.xlsx"));
        File file = chooser.showSaveDialog(btnExportExcel.getScene().getWindow());
        if (file == null) return;

        try {
            dataService.exportExcel(file.toPath());
            DialogHelper.showInfo("Xuất dữ liệu Excel", "Đã xuất dữ liệu thành công",
                    "Tệp Excel gồm các bảng phòng, khách thuê, hợp đồng, hóa đơn, chi tiết hóa đơn, tài sản, công việc, tin nhắn và doanh thu:\n"
                            + file.getAbsolutePath());
        } catch (IOException ex) {
            DialogHelper.showInfo("Lỗi xuất Excel", "Không thể xuất dữ liệu", ex.getMessage());
        }
    }

    private void loadSettings() {
        txtBuildingName.setText(settings.get("buildingName", txtBuildingName.getText()));
        txtOwnerName.setText(settings.get("ownerName", AccountService.getInstance().getDisplayName()));
        txtAddress.setText(settings.get("address", txtAddress.getText()));
        txtPhone.setText(settings.get("phone", txtPhone.getText()));
        txtElectricityPrice.setText(settings.get("electricityPrice", txtElectricityPrice.getText()));
        txtWaterPrice.setText(settings.get("waterPrice", txtWaterPrice.getText()));
        txtWifiPrice.setText(settings.get("wifiPrice", txtWifiPrice.getText()));
        txtGarbagePrice.setText(settings.get("garbagePrice", txtGarbagePrice.getText()));
        txtParkingPrice.setText(settings.get("parkingPrice", txtParkingPrice.getText()));
        cbWaterType.setValue(settings.get("waterType", cbWaterType.getValue()));
        cbBankName.setValue(settings.get("bankName", cbBankName.getValue()));
        txtBankNumber.setText(settings.get("bankNumber", txtBankNumber.getText()));
        txtBankHolder.setText(settings.get("bankHolder", txtBankHolder.getText()));
        txtBillingDay.setText(settings.get("billingDay", txtBillingDay.getText()));
        txtIssueDay.setText(settings.get("issueDay", txtIssueDay.getText()));
        txtDueDay.setText(settings.get("dueDay", txtDueDay.getText()));
    }

    private void saveSettings() {
        settings.put("buildingName", txtBuildingName.getText());
        settings.put("ownerName", txtOwnerName.getText());
        settings.put("address", txtAddress.getText());
        settings.put("phone", txtPhone.getText());
        settings.put("electricityPrice", txtElectricityPrice.getText());
        settings.put("waterPrice", txtWaterPrice.getText());
        settings.put("wifiPrice", txtWifiPrice.getText());
        settings.put("garbagePrice", txtGarbagePrice.getText());
        settings.put("parkingPrice", txtParkingPrice.getText());
        settings.put("waterType", cbWaterType.getValue());
        settings.put("bankName", cbBankName.getValue());
        settings.put("bankNumber", txtBankNumber.getText());
        settings.put("bankHolder", txtBankHolder.getText());
        settings.put("billingDay", txtBillingDay.getText());
        settings.put("issueDay", txtIssueDay.getText());
        settings.put("dueDay", txtDueDay.getText());
    }
}