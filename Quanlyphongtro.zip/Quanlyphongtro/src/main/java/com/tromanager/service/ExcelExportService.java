package com.tromanager.service;

import com.tromanager.model.Asset;
import com.tromanager.model.Contract;
import com.tromanager.model.Invoice;
import com.tromanager.model.InvoiceDetail;
import com.tromanager.model.MessageItem;
import com.tromanager.model.RevenueData;
import com.tromanager.model.Room;
import com.tromanager.model.TaskItem;
import com.tromanager.model.Tenant;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

final class ExcelExportService {
    void export(DataStore.Snapshot data, Path destination) throws IOException {
        Path file = destination.toAbsolutePath().normalize();
        Path parent = file.getParent();
        if (parent == null) {
            throw new IOException("Không xác định được thư mục lưu tệp Excel.");
        }
        Files.createDirectories(parent);

        try (Workbook workbook = new XSSFWorkbook()) {
            CellStyle headerStyle = workbook.createCellStyle();
            headerStyle.setFillForegroundColor(IndexedColors.DARK_BLUE.getIndex());
            headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerFont.setColor(IndexedColors.WHITE.getIndex());
            headerStyle.setFont(headerFont);

            writeRooms(workbook, headerStyle, data.rooms);
            writeTenants(workbook, headerStyle, data.tenants);
            writeContracts(workbook, headerStyle, data.contracts);
            writeInvoices(workbook, headerStyle, data.invoices);
            writeInvoiceDetails(workbook, headerStyle, data.invoices);
            writeAssets(workbook, headerStyle, data.assets);
            writeTasks(workbook, headerStyle, data.tasks);
            writeMessages(workbook, headerStyle, data.messages);
            writeRevenue(workbook, headerStyle, data.revenueData);

            try (OutputStream output = Files.newOutputStream(file)) {
                workbook.write(output);
            }
        }
    }

    private static void writeRooms(Workbook workbook, CellStyle headerStyle, List<Room> rooms) {
        List<List<?>> rows = new ArrayList<>();
        for (Room room : rooms) {
            rows.add(Arrays.asList(room.getId(), room.getName(), room.getFloor(), room.getBuildingName(),
                    room.getStatus() == null ? "" : room.getStatus().getDisplayName(),
                    room.getTenantName(), room.getPhoneNumber(), room.getContractStart(), room.getContractEnd(),
                    room.getPriceMonthly(), room.getElectricityPrice(), room.getWaterPrice(), room.getArea(),
                    room.getAmenities() == null ? "" : String.join(", ", room.getAmenities())));
        }
        writeSheet(workbook, headerStyle, "Phòng",
                List.of("Mã phòng", "Tên phòng", "Tầng", "Khu trọ", "Trạng thái", "Khách thuê", "Số điện thoại",
                        "Ngày bắt đầu hợp đồng", "Ngày kết thúc hợp đồng", "Giá thuê/tháng", "Giá điện",
                        "Giá nước", "Diện tích (m²)", "Tiện nghi"), rows);
    }

    private static void writeTenants(Workbook workbook, CellStyle headerStyle, List<Tenant> tenants) {
        List<List<?>> rows = new ArrayList<>();
        for (Tenant tenant : tenants) {
            rows.add(Arrays.asList(tenant.getId(), tenant.getName(), tenant.getPhone(), tenant.getRoomName(),
                    tenant.getIdCard(), tenant.getHometown(), tenant.getStartDate(), tenant.getDeposit(),
                    tenant.isTempReg() ? "Đã đăng ký" : "Chưa đăng ký", tenant.getEmail(), tenant.getAddress(),
                    tenant.getEmergencyContact(), tenant.getEmergencyPhone(), tenant.getCheckoutDate(),
                    tenant.getCheckoutNote()));
        }
        writeSheet(workbook, headerStyle, "Khách thuê",
                List.of("Mã khách", "Họ tên", "Số điện thoại", "Phòng", "CCCD", "Quê quán", "Ngày vào ở",
                        "Tiền cọc", "Tạm trú", "Email", "Địa chỉ", "Liên hệ khẩn cấp",
                        "SĐT liên hệ khẩn cấp", "Ngày trả phòng", "Ghi chú trả phòng"), rows);
    }

    private static void writeContracts(Workbook workbook, CellStyle headerStyle, List<Contract> contracts) {
        List<List<?>> rows = new ArrayList<>();
        for (Contract contract : contracts) {
            rows.add(Arrays.asList(contract.getCode(), contract.getRoomName(), contract.getTenantName(),
                    contract.getPhone(), contract.getOwnerName(), contract.getOwnerAddress(), contract.getOwnerPhone(),
                    contract.getTenantAddress(), contract.getTenantIdCard(), contract.getStartDate(),
                    contract.getExpiryDate(), contract.getRentPrice(), contract.getDeposit(),
                    contract.getRemainingDays(), contract.getStatus() == null ? "" : contract.getStatus().getLabel()));
        }
        writeSheet(workbook, headerStyle, "Hợp đồng",
                List.of("Mã hợp đồng", "Phòng", "Khách thuê", "Số điện thoại", "Chủ nhà", "Địa chỉ chủ nhà",
                        "SĐT chủ nhà", "Địa chỉ khách", "CCCD khách", "Ngày bắt đầu", "Ngày hết hạn",
                        "Tiền thuê", "Tiền cọc", "Số ngày còn lại", "Trạng thái"), rows);
    }

    private static void writeInvoices(Workbook workbook, CellStyle headerStyle, List<Invoice> invoices) {
        List<List<?>> rows = new ArrayList<>();
        for (Invoice invoice : invoices) {
            rows.add(Arrays.asList(invoice.getCode(), invoice.getRoomName(), invoice.getTenantName(),
                    invoice.getMonthPeriod(), invoice.getInvoiceDate(), invoice.getDueDate(),
                    invoice.getRoomAmount(), invoice.getElectricAmount(), invoice.getWaterAmount(),
                    invoice.getOtherAmount(), invoice.getDiscount(), invoice.getPreviousDebt(),
                    invoice.getTotalAmount(), invoice.getPaidAmount(),
                    invoice.getStatus() == null ? "" : invoice.getStatus().getLabel(),
                    invoice.getOldElectricReading(), invoice.getNewElectricReading(),
                    invoice.getOldWaterReading(), invoice.getNewWaterReading(), invoice.getOccupantCount(),
                    invoice.getCleaningAmount(), invoice.getTrashAmount(), invoice.getInternetAmount(),
                    invoice.getPaymentDate(), invoice.getPaymentMethod(), invoice.getPaymentNote(), invoice.getNote()));
        }
        writeSheet(workbook, headerStyle, "Hóa đơn",
                List.of("Mã hóa đơn", "Phòng", "Khách thuê", "Kỳ hóa đơn", "Ngày lập", "Hạn thanh toán",
                        "Tiền phòng", "Tiền điện", "Tiền nước", "Phí khác", "Giảm trừ", "Nợ cũ",
                        "Tổng tiền", "Đã thanh toán", "Trạng thái", "Điện cũ", "Điện mới", "Nước cũ",
                        "Nước mới", "Số người", "Vệ sinh", "Phí rác", "Internet", "Ngày thanh toán",
                        "Phương thức thanh toán", "Ghi chú thanh toán", "Ghi chú hóa đơn"), rows);
    }

    private static void writeInvoiceDetails(Workbook workbook, CellStyle headerStyle, List<Invoice> invoices) {
        List<List<?>> rows = new ArrayList<>();
        for (Invoice invoice : invoices) {
            for (InvoiceDetail detail : invoice.getDetails()) {
                rows.add(Arrays.asList(invoice.getCode(), invoice.getRoomName(), invoice.getMonthPeriod(),
                        detail.getSequence(), detail.getServiceName(), detail.getPreviousIndex(),
                        detail.getCurrentIndex(), detail.getQuantity(), detail.getUnitPrice(),
                        detail.getAmount(), detail.getNote()));
            }
        }
        writeSheet(workbook, headerStyle, "CT hóa đơn",
                List.of("Mã hóa đơn", "Phòng", "Kỳ hóa đơn", "Thứ tự", "Dịch vụ", "Chỉ số cũ",
                        "Chỉ số mới", "Số lượng", "Đơn giá", "Thành tiền", "Ghi chú"), rows);
    }

    private static void writeAssets(Workbook workbook, CellStyle headerStyle, List<Asset> assets) {
        List<List<?>> rows = new ArrayList<>();
        for (Asset asset : assets) {
            rows.add(Arrays.asList(asset.getCode(), asset.getName(), asset.getRoomName(), asset.getCategory(),
                    asset.getQuantity(), asset.getValue(), asset.getInstallDate(),
                    asset.getStatus() == null ? "" : asset.getStatus().getLabel(), asset.getSupplier(),
                    asset.getWarranty(), asset.getConditionNote(), asset.getMaintenanceNote(),
                    asset.getDisposalDate(), asset.getDisposalReason(), asset.getDisposalValue()));
        }
        writeSheet(workbook, headerStyle, "Tài sản",
                List.of("Mã tài sản", "Tên tài sản", "Phòng/vị trí", "Danh mục", "Số lượng", "Giá trị",
                        "Ngày lắp đặt", "Trạng thái", "Nhà cung cấp", "Bảo hành", "Tình trạng",
                        "Ghi chú bảo trì", "Ngày thanh lý", "Lý do thanh lý", "Giá trị thanh lý"), rows);
    }

    private static void writeTasks(Workbook workbook, CellStyle headerStyle, List<TaskItem> tasks) {
        List<List<?>> rows = new ArrayList<>();
        for (TaskItem task : tasks) {
            rows.add(Arrays.asList(task.getTitle(), task.getLocation(), task.getTime(),
                    task.getPriority() == null ? "" : task.getPriority().getLabel(),
                    task.getStatus() == null ? "" : task.getStatus().getLabel(),
                    task.getAssignee(), task.getDescription()));
        }
        writeSheet(workbook, headerStyle, "Công việc",
                List.of("Công việc", "Vị trí", "Thời gian", "Độ ưu tiên", "Trạng thái", "Người phụ trách",
                        "Mô tả"), rows);
    }

    private static void writeMessages(Workbook workbook, CellStyle headerStyle, List<MessageItem> messages) {
        List<List<?>> rows = new ArrayList<>();
        for (MessageItem message : messages) {
            rows.add(Arrays.asList(message.getSender(), message.getRoom(), message.getContent(),
                    message.getTime(), message.isOwner() ? "Chủ nhà" : "Khách thuê",
                    message.isUrgent() ? "Khẩn cấp" : ""));
        }
        writeSheet(workbook, headerStyle, "Tin nhắn",
                List.of("Người gửi", "Phòng", "Nội dung", "Thời gian", "Vai trò", "Mức độ"), rows);
    }

    private static void writeRevenue(Workbook workbook, CellStyle headerStyle, List<RevenueData> revenueData) {
        List<List<?>> rows = new ArrayList<>();
        for (RevenueData revenue : revenueData) {
            rows.add(Arrays.asList(revenue.getMonth(), revenue.getRevenueMillions()));
        }
        writeSheet(workbook, headerStyle, "Doanh thu",
                List.of("Tháng", "Doanh thu (triệu đồng)"), rows);
    }

    private static void writeSheet(Workbook workbook, CellStyle headerStyle, String name,
                                   List<String> headers, List<List<?>> rows) {
        Sheet sheet = workbook.createSheet(name);
        Row header = sheet.createRow(0);
        for (int column = 0; column < headers.size(); column++) {
            Cell cell = header.createCell(column);
            cell.setCellValue(headers.get(column));
            cell.setCellStyle(headerStyle);
        }

        for (int rowIndex = 0; rowIndex < rows.size(); rowIndex++) {
            Row row = sheet.createRow(rowIndex + 1);
            List<?> values = rows.get(rowIndex);
            for (int column = 0; column < headers.size(); column++) {
                Object value = column < values.size() ? values.get(column) : null;
                Cell cell = row.createCell(column);
                if (value instanceof Number number) {
                    cell.setCellValue(number.doubleValue());
                } else if (value != null) {
                    cell.setCellValue(value.toString());
                }
            }
        }

        sheet.createFreezePane(0, 1);
        if (!rows.isEmpty()) {
            sheet.setAutoFilter(new org.apache.poi.ss.util.CellRangeAddress(0, rows.size(), 0, headers.size() - 1));
        }
        for (int column = 0; column < headers.size(); column++) {
            sheet.autoSizeColumn(column);
            sheet.setColumnWidth(column, Math.min(sheet.getColumnWidth(column) + 512, 15000));
        }
    }
}
