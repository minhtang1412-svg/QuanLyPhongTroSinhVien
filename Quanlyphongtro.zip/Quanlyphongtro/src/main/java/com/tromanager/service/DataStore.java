package com.tromanager.service;

import com.tromanager.model.Asset;
import com.tromanager.model.Contract;
import com.tromanager.model.Invoice;
import com.tromanager.model.MessageItem;
import com.tromanager.model.RevenueData;
import com.tromanager.model.Room;
import com.tromanager.model.TaskItem;
import com.tromanager.model.Tenant;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InvalidObjectException;
import java.io.ObjectInputFilter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

final class DataStore {
    private static final long MAX_BACKUP_SIZE = 50L * 1024 * 1024;
    private final Path dataFile;
    private byte[] lastSavedBytes;

    DataStore() {
        this(Path.of(System.getProperty("user.home"), ".tromanager", "data.dat"));
    }

    DataStore(Path dataFile) {
        this.dataFile = dataFile.toAbsolutePath().normalize();
    }

    Path getDataFile() {
        return dataFile;
    }

    Snapshot load() throws IOException {
        if (!Files.exists(dataFile)) {
            return null;
        }
        Snapshot snapshot = readSnapshot(dataFile);
        lastSavedBytes = Files.readAllBytes(dataFile);
        return snapshot;
    }

    void save(Snapshot snapshot) throws IOException {
        writeSnapshot(snapshot, dataFile, true);
    }

    void exportBackup(Snapshot snapshot, Path backupFile) throws IOException {
        Path destination = backupFile.toAbsolutePath().normalize();
        if (destination.equals(dataFile)) {
            throw new IOException("Tệp sao lưu không được trùng với tệp dữ liệu đang sử dụng.");
        }
        writeSnapshot(snapshot, destination, false);
    }

    Snapshot readBackup(Path backupFile) throws IOException {
        return readSnapshot(backupFile);
    }

    private void writeSnapshot(Snapshot snapshot, Path destination, boolean updateCache) throws IOException {
        validate(snapshot);
        byte[] bytes = serialize(snapshot);
        if (updateCache && Arrays.equals(bytes, lastSavedBytes)) {
            return;
        }

        Path parent = destination.getParent();
        if (parent == null) {
            throw new IOException("Không xác định được thư mục lưu dữ liệu.");
        }
        Files.createDirectories(parent);
        Path temporaryFile = Files.createTempFile(parent, "tromanager-", ".tmp");
        boolean moved = false;
        try {
            Files.write(temporaryFile, bytes);
            try {
                Files.move(temporaryFile, destination, StandardCopyOption.ATOMIC_MOVE,
                        StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temporaryFile, destination, StandardCopyOption.REPLACE_EXISTING);
            }
            moved = true;
            if (updateCache) {
                lastSavedBytes = bytes;
            }
        } finally {
            if (!moved) {
                Files.deleteIfExists(temporaryFile);
            }
        }
    }

    private static byte[] serialize(Snapshot snapshot) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (ObjectOutputStream output = new ObjectOutputStream(bytes)) {
            output.writeObject(snapshot);
        }
        return bytes.toByteArray();
    }

    private static Snapshot readSnapshot(Path file) throws IOException {
        long size = Files.size(file);
        if (size == 0 || size > MAX_BACKUP_SIZE) {
            throw new IOException("Tệp dữ liệu trống hoặc vượt quá giới hạn 50 MB.");
        }

        try (ObjectInputStream input = new ObjectInputStream(Files.newInputStream(file))) {
            input.setObjectInputFilter(DataStore::filterInput);
            Object value = input.readObject();
            if (!(value instanceof Snapshot snapshot)) {
                throw new InvalidObjectException("Tệp không chứa dữ liệu TroManager hợp lệ.");
            }
            validate(snapshot);
            return snapshot;
        } catch (ClassNotFoundException | ClassCastException ex) {
            throw new IOException("Không thể đọc dữ liệu từ tệp đã chọn.", ex);
        }
    }

    private static ObjectInputFilter.Status filterInput(ObjectInputFilter.FilterInfo info) {
        if (info.depth() > 32 || info.references() > 100_000 || info.streamBytes() > MAX_BACKUP_SIZE) {
            return ObjectInputFilter.Status.REJECTED;
        }
        Class<?> type = info.serialClass();
        if (type == null) {
            return ObjectInputFilter.Status.UNDECIDED;
        }
        while (type.isArray()) {
            type = type.getComponentType();
        }
        if (type.isPrimitive() || isAllowedClass(type)) {
            return ObjectInputFilter.Status.ALLOWED;
        }
        return ObjectInputFilter.Status.REJECTED;
    }

    private static boolean isAllowedClass(Class<?> type) {
        String name = type.getName();
        return type == Snapshot.class
                || type == Object.class
                || type == Enum.class
                || type == String.class
                || type == Long.class
                || type == Integer.class
                || type == Boolean.class
                || type == Double.class
                || type == java.time.LocalDate.class
                || type == ArrayList.class
                || name.equals("java.util.Arrays$ArrayList")
                || name.equals("java.time.Ser")
                || name.startsWith("com.tromanager.model.") && type.isEnum()
                || name.startsWith("com.tromanager.model.")
                && (type == Asset.class || type == Contract.class || type == Invoice.class
                || type == MessageItem.class || type == RevenueData.class || type == Room.class
                || type == TaskItem.class || type == Tenant.class
                || name.equals("com.tromanager.model.InvoiceDetail"));
    }

    private static void validate(Snapshot snapshot) throws InvalidObjectException {
        if (snapshot == null
                || !valid(snapshot.rooms, Room.class)
                || !valid(snapshot.tenants, Tenant.class)
                || !valid(snapshot.contracts, Contract.class)
                || !valid(snapshot.invoices, Invoice.class)
                || !valid(snapshot.assets, Asset.class)
                || !valid(snapshot.tasks, TaskItem.class)
                || !valid(snapshot.revenueData, RevenueData.class)
                || !valid(snapshot.messages, MessageItem.class)) {
            throw new InvalidObjectException("Cấu trúc dữ liệu TroManager không hợp lệ.");
        }
    }

    private static <T> boolean valid(List<?> values, Class<T> itemType) {
        return values != null && values.stream().allMatch(itemType::isInstance);
    }

    static final class Snapshot implements java.io.Serializable {
        private static final long serialVersionUID = 1L;

        final List<Room> rooms;
        final List<Tenant> tenants;
        final List<Contract> contracts;
        final List<Invoice> invoices;
        final List<Asset> assets;
        final List<TaskItem> tasks;
        final List<RevenueData> revenueData;
        final List<MessageItem> messages;

        Snapshot(List<Room> rooms, List<Tenant> tenants, List<Contract> contracts,
                 List<Invoice> invoices, List<Asset> assets, List<TaskItem> tasks,
                 List<RevenueData> revenueData, List<MessageItem> messages) {
            this.rooms = new ArrayList<>(rooms);
            this.tenants = new ArrayList<>(tenants);
            this.contracts = new ArrayList<>(contracts);
            this.invoices = new ArrayList<>(invoices);
            this.assets = new ArrayList<>(assets);
            this.tasks = new ArrayList<>(tasks);
            this.revenueData = new ArrayList<>(revenueData);
            this.messages = new ArrayList<>(messages);
        }
    }
}
