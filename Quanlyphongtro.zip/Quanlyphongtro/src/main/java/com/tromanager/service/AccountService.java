package com.tromanager.service;

import java.util.prefs.Preferences;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public final class AccountService {
    private static final String DEFAULT_PASSWORD = "admin123";
    private static final int ITERATIONS = 120_000;
    private static final int KEY_LENGTH = 256;
    private static final int SALT_LENGTH = 16;
    private static final int HASH_LENGTH = KEY_LENGTH / Byte.SIZE;
    private static final AccountService INSTANCE =
            new AccountService(Preferences.userNodeForPackage(AccountService.class));

    private final Preferences preferences;
    private String username = "admin";
    private String passwordHash;
    private String passwordSalt;
    private String displayName;
    private boolean firstLogin;
    private boolean credentialsRecovered;

    AccountService(Preferences preferences) {
        this.preferences = preferences;
        String storedSalt = preferences.get("passwordSalt", "");
        String storedHash = preferences.get("passwordHash", "");
        if (storedSalt.isEmpty() && storedHash.isEmpty()) {
            setCredentials(DEFAULT_PASSWORD, true);
        } else if (isValidCredentials(storedSalt, storedHash)) {
            passwordSalt = storedSalt;
            passwordHash = storedHash;
        } else {
            credentialsRecovered = true;
            setCredentials(DEFAULT_PASSWORD, true);
        }
        displayName = preferences.get("displayName", "Nguyễn Minh Tuấn");
        firstLogin = preferences.getBoolean("firstLogin", true);
    }

    public static AccountService getInstance() {
        return INSTANCE;
    }

    public boolean authenticate(String username, String password) {
        return this.username.equals(username == null ? "" : username.trim())
            && verify(password == null ? "" : password);
    }

    public boolean updatePassword(String currentPassword, String newPassword, String confirmation) {
        if (!verify(currentPassword) || newPassword == null || newPassword.length() < 8
                || !newPassword.equals(confirmation)) {
            return false;
        }
        setCredentials(newPassword, false);
        return true;
    }

    public String resetPassword(String username) {
        if (!this.username.equals(username == null ? "" : username.trim())) {
            return null;
        }
        String temporaryPassword = generateTemporaryPassword();
        setCredentials(temporaryPassword, true);
        return temporaryPassword;
    }

    public boolean isFirstLogin() {
        return firstLogin;
    }

    public boolean wereCredentialsRecovered() {
        return credentialsRecovered;
    }

    public String getUsername() {
        return username;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        if (displayName != null && !displayName.trim().isEmpty()) {
            this.displayName = displayName.trim();
            preferences.put("displayName", this.displayName);
        }
    }

    private boolean verify(String candidate) {
        return constantTimeEquals(passwordHash, hash(candidate == null ? "" : candidate, passwordSalt));
    }

    private void setCredentials(String password, boolean firstLogin) {
        String salt = createSalt();
        String hash = hash(password, salt);
        preferences.put("passwordSalt", salt);
        preferences.put("passwordHash", hash);
        this.passwordSalt = salt;
        this.passwordHash = hash;
        this.firstLogin = firstLogin;
        preferences.putBoolean("firstLogin", firstLogin);
    }

    private static boolean isValidCredentials(String salt, String hash) {
        try {
            return Base64.getDecoder().decode(salt).length == SALT_LENGTH
                    && Base64.getDecoder().decode(hash).length == HASH_LENGTH;
        } catch (IllegalArgumentException ex) {
            return false;
        }
    }

    private static String createSalt() {
        byte[] salt = new byte[SALT_LENGTH];
        new SecureRandom().nextBytes(salt);
        return Base64.getEncoder().encodeToString(salt);
    }

    private static String hash(String value, String salt) {
        try {
            PBEKeySpec spec = new PBEKeySpec(value.toCharArray(), Base64.getDecoder().decode(salt), ITERATIONS, KEY_LENGTH);
            byte[] encoded = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
            spec.clearPassword();
            return Base64.getEncoder().encodeToString(encoded);
        } catch (Exception ex) {
            throw new IllegalStateException("Không thể tạo hash mật khẩu", ex);
        }
    }

    private static boolean constantTimeEquals(String left, String right) {
        return MessageDigest.isEqual(left.getBytes(StandardCharsets.UTF_8), right.getBytes(StandardCharsets.UTF_8));
    }

    private static String generateTemporaryPassword() {
        byte[] bytes = new byte[12];
        new SecureRandom().nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes).substring(0, 12);
    }
}
